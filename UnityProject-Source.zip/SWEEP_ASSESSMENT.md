# Sweep assessment prototype

Applied to the current ARTraining scene. This is a configurable prototype criterion, not an official training standard. It uses the current centre aim ray and powder nozzle aim point; no hand tracking, camera-image analysis or rotation-angle scoring was added.

## Setup and tuning

The existing SIH Equipment Interaction object now has one SIHSweepAssessment component, referenced by the existing SIHAimSprayController. No additional placement, equipment or aim controller is created. Tools > SIH > Setup Sweep Assessment repairs this wiring and backs up both the saved scene and the live scene before editing. Tools > SIH > Setup Aim and Spray also preserves/adds this connection for future setup runs. Existing Inspector tuning and event listeners are retained on rerun.

SIHSweepAssessment Inspector defaults:

- Required Alternating Passes: 2. Either direction can be first; the next credited pass must be opposite.
- Minimum Travel: 0.55 of the full fire-base target diameter per pass.
- Reversal Threshold: 0.08 diameters back from the furthest point, rejecting small oscillations.
- Smoothing Seconds: 0.06. This smooths assessment only; aiming and powder remain responsive.
- Minimum Pass Seconds: 0.45, a prototype minimum leg interval.
- Maximum Sample Gap: 0.25 seconds. Longer frames stop spray and discard the partial pass.
- Maximum Sample Jump: 0.25 diameters per sample. A discontinuous position jump breaks the partial pass instead of earning credit.

The horizontal sweep axis is captured from the camera right vector projected onto the placement surface when pin removal first enters Aim. The axis and target centre/width are stored in the hazard's frame. They are not recomputed from subsequent camera movement or on release/re-enable. Actual valid hit displacement along this fixed axis is measured in fire-base diameters, so rotation without movement of the hit point earns nothing. Phone movement/rotation that really moves the valid spray hit across the base can earn credit through the existing aiming controls.

Only a selected extinguisher with its pin removed, active spray, reliable AR tracking and a valid base hit can submit samples. ARSession must be SessionTracking with NotTrackingReason.None. Release, miss, cancellation, focus/pause/disable or tracking loss ends the partial pass. Completed passes and the last credited direction persist. Resume always seeds a fresh segment; distant disconnected positions are never joined. Tracking interruptions have no trainee mistake counters or penalties.

Health remains independent in SIHFireHazard. Holding one spot can extinguish the fire without demonstrating a sweep. No health bonus, automatic reignition or technique credit is awarded in that case. Sampling occurs before this frame's health update so a genuinely completed final pass on the extinction frame is not lost.

## Feedback and events

- Valid target, no credited pass: “Sweep slowly from side to side.”
- Invalid target: “Aim at the base.”
- At least one pass: “Good sweep—keep going.”
- Criterion met: “Sweep technique complete.”
- Tracking unreliable: “Tracking paused — resume when stable.”
- Extinction before completion: “Fire extinguished; sweep technique not demonstrated.”

SIHSweepAssessment.SweepCompleted (C# event) and OnSweepCompleted (Inspector UnityEvent) each fire once per attempt, with IsComplete latched before callbacks. CompletedPasses and IsComplete expose results. The existing fire completion events still fire independently. After successful sweep and extinction the main prompt says “Fire extinguished”; the sweep completion flag remains available. Reset clears the axis, samples, completed passes, feedback source and completion flag.

## Validation performed

Unity compilation passed. Deterministic geometric tests passed for holding still, tiny shakes, no-spray movement, two alternating passes, single completion event, release/resume at a distant position, retention of completed passes, rejection of repeated same-direction passes, hit jumps, long frame gaps, fixed axis, unchanged hit under rotation, ended attempts, reset and different fire sizes.

Synthetic Play mode integration passed for the existing placement/grounding/selection/pin flow, pre-pin spray lock, Aim transition, actual hit/nozzle alignment, accurate and missed damage, UI input blocking, release/cancel/drag-off/focus/pause/disable, tracking interruption retaining completed passes without joining a new partial pass, incomplete-extinction feedback, one-shot fire completion, retained hazard root and complete reset. Unity was unfocused during one test; its guard correctly blocked spraying. The test explicitly simulated focus and restored it afterward rather than weakening the production guard.

No Android build, physical phone test, real AR tracking-loss test or new UI visual preview was performed for this step. Threshold feel, real tracking noise and feedback readability need device validation. No claim is made that these thresholds assess an official firefighting technique standard.

## Exact Android test checklist

1. Open Assets/Scenes/ARTraining.unity in Unity 6000.3.24f1. Wiring is already applied. Wait for compilation; if needed run Tools > SIH > Setup Sweep Assessment.
2. File > Build Profiles > existing Android profile > select the connected ARCore phone as Run Device > Build And Run. Keep OpenGLES3, Depth Texture, camera and background renderer settings unchanged.
3. Scan enough floor, place the larger fire, select the extinguisher and remove the safety pin. Aim at the base. Confirm “Sweep slowly from side to side.”
4. Hold the spray at one fixed base point. It should lose health, but no sweep credit should appear. After about five seconds expect “Fire extinguished; sweep technique not demonstrated.” It must remain extinguished.
5. Tap RESET and repeat placement/selection/pin. Spray with tiny shakes around one spot: no pass. Moving the reticle side to side with the spray button released must also earn no pass.
6. Reset again. While holding spray and keeping the reticle on the base, move from near the left side to near the right side over roughly 1–1.5 seconds. Confirm “Good sweep—keep going.” Reverse and cover the width back to the left over roughly 1–1.5 seconds. Confirm “Sweep technique complete.” Continue accurate spray to extinguish; completion must not fire again.
7. Reset. Start a short partial movement, release, aim elsewhere in the base, then press again and hold still. No false pass should appear. After a genuine first complete pass, release; that completed pass should remain, but a fresh opposite pass must cover sufficient continuous travel.
8. While spraying, aim outside the base: expect “Aim at the base.” Return to a distant base position and hold still; the missed interval must not complete a pass.
9. After a credited pass, cover/move the phone enough to lose reliable tracking. Spray must stop; no mistake should be recorded. Recover tracking and press again. The credited pass should remain, while the partial movement restarts. Also test app backgrounding, touch cancellation and disabling the interaction in Editor.
10. RESET during spraying and after completion. Confirm scanning prompts, restored large fire on replacement, fresh health, unselected equipment, intact pin and zero sweep progress. A fresh two-pass attempt must be possible.
11. Change Fire Size on the FireHazard prefab, rebuild and repeat the two-pass test. Travel should scale with the visible base/target width. Leave the extinguisher at its existing realistic scale.

Backups: Backups/Sweep_* holds pre-change files. Backups/SweepSetup_* holds each setup's saved/live scene copies. Tests are recorded in .utmp/TestSweep.cs and .utmp/TestSweepIntegration.cs.

﻿# SIH practical-training repair — 28 September 2026

The existing project and ARTraining scene were repaired in place. No package upgrade, input-system migration, graphics-API change, or replacement project was introduced.

## Recoverable backup

`Backups/BeforePracticalRepair_20260928_115426` contains Assets (including .meta GUIDs), Packages, ProjectSettings, and a live-scene copy. Each repair command also creates a timestamped `Backups/PracticalRepair_*` folder. This folder was not a Git repository before editing. Restore only with Unity closed and after separately preserving any subsequent work.

## Causes established from the current project

- `SIHScenarioInteraction.OnPlaced` entered IdentifyHazard, created the large world-space scenario label, and required answers before selecting equipment or removing the pin. The scenario setup generator could restore this flow.
- Extinguisher spawning tried only two automatic locations beside the fire. It additionally required a PlaneWithinPolygon hit-type flag despite casting with Planes. Either failure left no instance. Scenario progression displayed a selection instruction independently of whether spawning succeeded. This explains a concrete no-instance path; the exact phone recording's instance state was unavailable.
- The equipment prefab itself had active meshes, URP/Lit materials, unit scale, a contact foot at local Y=0, and an associated selection collider. Live scene reference and camera-layer checks passed.
- Fire placement accepted the first plane hit without upward-horizontal, tracking, or boundary checks. The scene supplied an 8 cm placement offset, then the fire controller moved the root again. Child particles used world simulation, so existing particles did not follow the corrected root. No AR anchor held the placement. These are verified grounding defects; physical appearance from multiple phone angles still requires on-device verification.
- Selection prompts could override scanning/spawn-failure status. There was no explicit equipment-placement stage or preview.
- New attempts were configured for the old question-scoring rubric.

## Changes

- `Assets/Scripts/AR/ARPlacementController.cs`: validated Planes raycasts, footprint boundary checks, surface preview/reticle, user tap confirmation, AR plane-attached anchors, failure/retry status, anchor cleanup, and renderer-only plane hiding. Plane tracking/raycast managers stay enabled. No camera-relative fallback or unrelated-plane resnapping.
- `SIHGroundContact.cs`: authored local contact with one 2 mm coplanar-rendering clearance. `SIHPlacementPreview.cs`: non-interactive fire-footprint volume and realistic equipment mesh ghosts. The preview material is stored in Resources so Android includes its transparent shader variant.
- `SIHExtinguisherSelection.cs`: explicit PlaceExtinguisher stage, same-ground/footprint separation checks, one confirmed instance, renderer/material/camera/collider validation before selection instructions, and cleanup of instance/anchor references.
- `SIHFireHazard.cs`: local particle simulation, final ground alignment before resetting emission, and anchor-relative aim geometry. Enlarged fire settings and health fade remain.
- `SIHScenarioInteraction.cs`, `SIHScenarioUI.cs`: metadata-only scenario, no answer cards, no answer gates, no world scenario label. Old enum values remain to preserve serialization compatibility, but no active flow enters them.
- `SIHAimSprayController.cs`, `SIHTrainingPrompts.cs`, `SIHPlacementHUD.cs`: placement states, tracking gates, compact safe-area prompts, EXTINGUISHER locator with direction/distance, and development-only diagnostics (off by default).
- `SIHSafetyPin.cs`: unfinished pin removal cancels on suspension, focus loss, or tracking loss without awarding completion.
- `SIHAssessmentRecorder.cs`, `SIHAttemptRecord.cs`, `SIHAttemptStore.cs`: new `practical-3` rubric/schema 3 with six criteria weighted 20/20/20/20/10/10; threshold and aim-duration settings preserved. Setup time is excluded. Legacy schema 1/2 records keep their stored rules and scores.
- `SIHTrainingRoute.cs`: retains manual exit/ordered waypoints/assembly flow; removes the redundant polygon hit-type gate while retaining geometric containment. Restart keeps a confirmed route in the valid current session and requires fresh fire/equipment placement.
- `Assets/Editor/SIHPracticalRepair.cs`: idempotent, backed-up in-place repair. Existing scenario, fire, and equipment setup generators are consistent with the repaired flow.
- `Assets/Editor/SIHPracticalValidation.cs`: repeatable Editor checks; results in `Logs/SIHPracticalValidation.txt`.
- Repaired `Assets/Scenes/ARTraining.unity` and existing fire/equipment prefabs through Unity Editor APIs; existing GUIDs retained. Original Cube preserved.

## Validation and limits

The Editor suite passed 140 checks: scene wiring, Android scene list/profile configuration, camera/renderer/Depth Texture, equipment renderer/material/layer/collider checks, boundary containment, ground contact, gradual fire health, invalid-aim rejection, stationary/tiny/disconnected sweep rejection, two alternating sweeps with one completion event, route dwell/jump/pause guards, six-item scoring, missing evidence, fresh-store save/reload, historical score preservation, and corrupt-checkpoint recovery. Storage checks use an isolated Temp folder, not trainee records.

Play Mode started in RouteSetup with quizzes disabled and no equipment spawned before placement. The screenshot is `Assets/Logs/SIH-PlayMode.png`. The Windows Editor had no ARCore subsystem, so this is a HUD/startup smoke check, not an AR placement test. Pipeline requests sometimes timed out while Unity compiled/reloaded; completion was checked through saved validation output and Editor logs.

Not yet verified on a phone: physical ground alignment, anchor recovery, selection/pin touch targets, transparent ghost rendering, device-local persistence after app restart, or an end-to-end Android attempt. No APK/device Build And Run is claimed.

## Unity setup and Android Build And Run

1. Open this project with Unity **6000.3.24f1**. Open `Assets/Scenes/ARTraining.unity`; remain out of Play Mode.
2. Run **Tools > SIH > Repair Practical Training**. It backs up the current scene/prefabs, preserves existing references, and saves the repaired scene. Do not use an older recovery scene.
3. Run **Tools > SIH > Validate Practical Training**. Confirm the success message and review `Logs/SIHPracticalValidation.txt`.
4. Open **File > Build Profiles**. Select **Android** and **Switch Platform** if Android is not already active. In the scene list, enable **Assets/Scenes/ARTraining.unity** only. If using a custom profile with its own scene list, ensure it includes that same repaired scene.
5. Retain **OpenGLES3**, existing Android/input/XR settings, **AR Foundation/ARCore 6.3.5**, Mobile Renderer's **AR Background Renderer Feature**, and Mobile RP Asset's enabled **Depth Texture**.
6. Connect an ARCore-compatible Android phone by USB, enable USB debugging, authorize the laptop on the phone, and choose it under **Run Device**.
7. For diagnosis enable **Development Build**. On **SIH Training Prompts > SIH Placement HUD**, enable **Show Development Diagnostics** only if needed. The panel is suppressed in non-development builds.
8. Click **Build And Run**, save a new APK under `Builds/Android/SIH-Practical.apk`, and grant camera permission on first launch. Normal demonstration builds should leave development diagnostics off.

## Phone checklist

- Manually place exit, ordered waypoints and assembly; review/confirm. No quiz or answer card appears.
- Scan textured ground. Verify a ghost/reticle, useful no-hit status, wall/ceiling/boundary rejection, and deliberate ground confirmation.
- Walk around the placed fire: check base contact, no old floating particle cloud, and stable position. Confirm new plane visuals stay hidden.
- Place the extinguisher separately outside the fire footprint. Check exactly one instance, grounded base, small label, and off-screen direction/distance.
- Select, release touch, remove pin with a separate gesture. Verify spray is locked until then.
- Hold Spray at the base; check gradual damage, endpoint guidance and two alternating passes. Repeat holding one spot: fire can go out but sweep earns zero.
- Release/cancel touch, background the app, and interrupt tracking: no continued spray or false sweep/arrival/pin progress.
- Identify the exit, then physically approach ordered stops and dwell at assembly. Check results against observed evidence and the 100-point rubric.
- Restart: retain current-session route, place fresh fire/equipment, with no duplicate or stale instance. Reconfigure: clear route. New AR session: no old raw coordinates reused.
- In airplane mode complete/reload a result, then kill/relaunch during another attempt. Check immutable history and an interrupted record; confirm old rubric scores remain unchanged.

# Hazard identification and extinguisher choice — prototype-2

The current ARTraining scene now asks two explicit questions after fire placement and before equipment selection/pin removal. The scene is preserved; backups are in `Backups/Scenario_20260927_224343` and per-setup `Backups/ScenarioSetup_*` directories.

## Unity setup

1. Open `D:\AR` in Unity 6000.3.24f1 and open `Assets/Scenes/ARTraining.unity`. Wait for compilation.
2. The scene is wired. To reapply wiring, leave Play mode and run **Tools > SIH > Setup Hazard and Equipment Questions**. This backs up the saved/live scene and reuses the existing state controller, equipment component, assessment recorder and Canvas.
3. Select `Assets/Scenarios/OutdoorWood_UK.asset` to inspect scenario ID/version, jurisdiction, description/context label, answer IDs, accepted equipment choices, feedback and sources. Setup preserves an existing scenario asset rather than overwriting its content.
4. On **SIH Equipment Interaction > SIH Assessment Recorder > Rules**, the new version is `prototype-2`. The previous prototype threshold and time thresholds remain configured as before. Do not change old record files to apply new rules.
5. **File > Build Profiles > Android**: keep the existing profile and settings; ensure ARTraining is included, connect the phone, choose Run Device, then **Build And Run** with a new APK filename.

## Defined scenario and educational basis

This is a supplied, simulated outdoor-yard wood fire: dry untreated wood, open/calm conditions, no live electrics, liquids, gas or cooking oil, clear escape route and established alarm/evacuation arrangements. The question panel and contextual world label identify it. The app does not infer materials from flames or the phone camera. A camera view of an indoor room does not turn this into a recommendation to use powder indoors.

The naming system is **UK fire classes (EN 2)**. The hazard answer is **Class A — combustible solids (wood)**. Alternatives are Class B liquids and Class F cooking oils/fats; feedback refers to the stated material.

The accepted equipment profile is specifically **Firechief FXP6: 6 kg ABC powder, 43A 233B C**, represented by the existing generic powder training model. It is not a certified digital replica or a claim that any powder cylinder has this rating. The manufacturer lists FXP6 height 531 mm, consistent with the existing roughly 0.55 m prototype. The existing powder discharge is retained; the prototype's five-second fire-health duration is not the manufacturer's actual cylinder discharge duration.

The offered BC-only powder and CO2 cards explicitly have no Class A rating and are not accepted for this stated wood scenario. A-rated water/foam may also be suitable, but are not offered in this training kit; they are not presented as wrong answers. Suitability is attached to each configured choice, not inferred from the word 'powder'.

Sources, also stored in the scenario asset:

- [Firechief manufacturer product sheet](https://firechiefglobal.com/wp/wp-content/uploads/2019/09/FMP1_FXP2-12_Product_Sheet_May21-1-1.pdf): page 2 identifies the specific FXP6 capacity/rating and wood/paper application.
- [Firechief service manual](https://firechiefglobal.com/wp/wp-content/uploads/2022/04/Firechief-Extinguisher-Service-Manual-2022-1.pdf): FXP6 uses ABC40 powder.
- [UK Government fire-safety guidance](https://www.gov.uk/government/publications/fire-safety-risk-assessment-offices-and-shops/fire-safety-risk-assessment-offices-and-shops-accessible): class definitions and agent applications; powder can impair visibility/breathing and permit re-ignition and is generally unsuitable for enclosed spaces.

The outdoor condition is a deliberate scenario-design choice informed by that guidance; it is not an automatic safety assessment of the user's location.

## Flow and configuration boundaries

After route confirmation and fire placement:

`IdentifyHazard -> ChooseExtinguisher -> SelectEquipment -> PullPin -> Aim/Spray/Sweep -> FindExit/Evacuate -> Results`

The existing `SIHAimSprayController` owns these states; its original enum values were retained. ScenarioInteraction manages question submissions and uses the existing placement/reset events. Both equipment selection/pin input and spray eligibility are gated. No points are awarded just for seeing the question or displaying equipment.

Submit one card, read feedback, then use **CONTINUE / TRY AGAIN**. Incorrect answers stay on that question. A feedback latch plus a frame guard rejects repeated taps/events before deliberate continuation. Pressing Try Again and explicitly submitting an answer again is a new submission. Restart and Reconfigure remain accessible on the question screen.

Several configured choices can be accepted: each accepted card is checked independently. The installed physical/spray implementation supports the `abc6-fxp6` profile, type `ABC powder`, rating `43A 233B C`. Multiple suitable units/cards with that profile are supported. To add a different accepted agent such as water or CO2, first implement its matching model/label/discharge and extend profile validation. Unsupported accepted profiles produce a configuration error; they are not scored as trainee mistakes. Wrong-agent cards never relabel the current powder model or emit a mismatched discharge.

The selected unit has an associated training-profile label. The existing shaped model, conforming dry-powder label, pin, collider and powder particles are preserved. The scenario asset is copied for the placed-fire attempt so choices do not change midway through an attempt.

## New scoring and records

| Criterion | Points |
|---|---:|
| Hazard identification | 10 |
| Suitable extinguisher choice | 20 |
| Pin sequence | 10 |
| Valid-aim spraying time | 15 |
| Required sweep passes | 15 |
| Fire extinguished | 10 |
| Exit identified | 10 |
| Ordered route and assembly | 10 |
| Total | 100 |

For each question, a correct **first** submission earns full points. Any incorrect submission makes that question worth zero for the attempt, even after correction. The results say **Correct after retry**. Wrong submissions are recorded as mistakes without a second deduction. With everything else complete, one hazard retry gives 90/100; one equipment retry gives 80/100; retrying both gives 70/100. The overall prototype threshold/completion/evidence requirements remain unchanged. This is a project scoring policy, not an official fire-safety standard.

New records use schema 2 and rules version `prototype-2`. They retain scenario ID/version/description/jurisdiction/sources, explicit submitted answer IDs/labels, feedback, correctness, sequence number, unique submission ID and UTC time. Existing measurement/duration/route fields remain. Reset clears question submissions and flags, creates a fresh attempt record and keeps the route only in the same valid AR session.

The existing storage folder remains `Application.persistentDataPath/SIHAssessments/v1/` so old history stays discoverable; the folder name is not the record schema. The reader accepts schema 1 and 2. Completed historical records are displayed with their saved original weights/available totals and are never rescored using current Inspector rules.

## Android acceptance steps

1. Configure/confirm the route and place fire. Check the supplied wood description and UK class labels. Before answering, try the physical extinguisher/pin and any spray control: no progression or discharge should occur.
2. Choose Class A, continue, then the FXP6 ABC powder card and continue. Tap the physical powder model, pull the pin and finish normal training. Expect question awards 10/10 and 20/20, plus the new weights, with a potential 100/100 total.
3. Restart. Choose Class B first. Rapidly tap again while feedback is visible: one incorrect submission/mistake only. Try Again, then Class A. Finish normally. Hazard must show Correct after retry and 0/10; otherwise-full result is 90/100.
4. Restart. Answer hazard correctly, choose BC-only powder or CO2, read the scenario-specific explanation, then correct to ABC powder. Equipment/pin/spray stay locked until acceptance/continuation. Expect Correct after retry and 0/20; otherwise-full result is 80/100.
5. Test both questions wrong then corrected. Expect two wrong-answer entries and 70/100 if every other item earns credit, with no extra mistake deduction. Repeated accepted-answer/Continue taps must not award twice or skip equipment selection.
6. In an Editor test copy of the scenario, add another accepted card with a unique ID and the same supported type/rating/profile (for example a second serviceable FXP6 unit). Both configured choices must work. Do not mark a different agent accepted without implementing its physical/discharge profile. Restore the intended scenario after this configuration test.
7. Restart during feedback and again after equipment choice. Check questions, retry counts and points clear, while the confirmed route remains in the valid session. Reconfigure should clear the route/exercise while retaining historical records.
8. Check portrait/landscape and notched-screen safe areas. Scroll cards if needed. Confirm feedback and reset buttons remain readable; dragging/tapping the panel must not place another fire or select world objects underneath.
9. Inspect a known old record through Last Results and compare its original version, points and available total. This phone-history check is still required; desktop compatibility tests do not establish phone offline reload.

## Validation status

Desktop model/record tests and synthetic Play mode event tests cover correct-first submissions, wrong hazard/equipment then correction, duplicate submissions/events, multiple configured accepted powder-profile choices, pre-answer interaction gates, downstream full-success training and reset. Schema-1 fixture files were read without rewriting/rescoring; schema-2 serialization was checked. Those are compatibility tests, not a phone offline-reload test.

**The phone no-sweep failure case and offline reload remain UNVERIFIED.** They are not reported as passed by this work. No new Android APK build or phone run has been performed. Real mobile touch behavior, tracking recovery, safe-area rendering and selected-model label readability require the tests above.

Test scripts are under `Tests/Scenario`, outside runtime Assets. They use synthetic plane/input/frame advancement and isolated `.utmp` assessment storage. They do not modify phone assessment history.

Final checks: Unity compilation completed without errors. Editor question previews were inspected in landscape and portrait; the revised choice panel is opaque and blocks UI rays at the center and screen edges. Repeated setup kept 87 scene objects, one scenario interaction and one assessment recorder. All existing prefabs, materials, renderer/settings assets, packages and ProjectSettings matched the pre-task backup; camera serialization was unchanged. Depth Texture, AR Background Renderer Feature and TrackableType.Planes remain intact.

## Compact question UI (28 September 2026)
The question UI now occupies the lower 52% of the safe area in portrait (72% in landscape), leaving the upper camera view visible. Descriptions, answer cards and submitted-answer feedback use the same scroll area. Continue/retry and restart/reconfigure remain accessible below it. A transparent full-screen input shield prevents touches passing through to AR interactions while questions are active. The sheet itself is opaque to prevent older HUD controls showing through.

Tune Portrait Panel Height / Landscape Panel Height on SIHScenarioUI on the SIH Training Prompts canvas. The existing Tools > SIH > Setup Hazard and Equipment Questions command recreates this compact layout and backs up the scene. ARTraining is already wired.

The compact portrait layout was inspected in Unity Play mode using synthetic scenario state, not a live phone camera. On Android, Build And Run ARTraining, configure the route, place the fire, scroll each question, submit an answer, read feedback and continue. Check that bottom buttons stay above the system gesture area and touches in the clear camera area cannot select equipment before answering. Phone verification is still required; the no-sweep failure and offline reload tests remain unverified.

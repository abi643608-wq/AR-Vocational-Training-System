# Aim and spray prototype

Applied directly to the current ARTraining scene. No separate TrainingManager or duplicate equipment controller was created. No sweep assessment, technique credit or scoring is included.

## Unity steps

1. Open D:/AR with Unity 6000.3.24f1, then Assets/Scenes/ARTraining.unity. Wait for compilation.
2. Wiring is already applied. To repair/reapply it, use Tools > SIH > Setup Aim and Spray. It backs up the current disk scene and live scene, updates existing objects and preserves references. Do not load an older scene backup.
3. Select Assets/Prefabs/Fire/FireHazard.prefab. On SIHFireHazard tune Fire Size (default 1.5), Required Spray Seconds (5), and Base Target Radius (.35 metres before Fire Size scaling). Original Scale (.3,.3,.3) records the original model scale; leave it unchanged.
4. File > Build Profiles > existing Android profile. Keep ARTraining in the scene list, OpenGLES3 and the existing XR/camera/renderer settings. Connect the ARCore phone with USB debugging, select Run Device, then Build And Run.

## Android acceptance checklist

- Scan a broad textured floor. Place the fire once. Scan at least 1.6 metres beside it if equipment is waiting for measured ground. One extinguisher should appear with no overlap. It remains approximately 56 cm tall.
- Check the enlarged flame from low and side views: its logical root is grounded at the detected plane, with no inherited .08 m placement offset. Flame, smoke and sparks use the same 1.5 multiplier. Confirm base contact visually on the actual device; AR depth/plane accuracy cannot be validated by desktop simulation.
- Check orange/red flame detail and the reduced floor glow under both bright and dim room lighting. Verify smoke/sparks and frame rate on the target phone.
- Before selection/pin removal, spraying is unavailable. Select the extinguisher, release, then tap the pin ring. Confirm the existing extraction animation followed by “Aim at the base of the fire.”
- The centre reticle turns green and says ON TARGET when it intersects the base zone; orange indicates a miss. Aim above or beside the fire and hold HOLD TO SPRAY for over five seconds: powder should be visible but fire health must not decrease.
- Aim at the base and hold: the nozzle swivels at its existing hose joint; powder comes from its tip toward the reticle aim point. Flame emission, size, brightness, light and audio diminish with accumulated accurate spray time.
- Release: powder and damage stop immediately. Drag the holding finger outside the button; cancel the touch; background the app or lock the phone while holding. Each must stop spray, and returning to the app must require a fresh press. Test a second finger without releasing the original finger; it must not take over the hold.
- Spray accurately for about five accumulated seconds (misses and released periods do not count). Confirm “Fire extinguished”, no new flames/sparks, remaining particles/smoke fade, and fire audio stops. Later taps must not restart emission or repeat completion. The FireHazard logical root remains present until Reset.
- Tap RESET while spraying, during pin extraction, and after extinction. Confirm spray stops, fire/equipment are cleared and scanning/placement prompts return. Place again: full configured larger fire, unselected extinguisher, intact pin, full health, and a new five-second extinguishing sequence.
- Tap/hold RESET and spray UI: no world selection, fire placement or duplicate equipment should occur. Test portrait/landscape and display cutouts if the configured app supports rotation.

## Components and integration

- SIHAimSprayController on the existing SIH Equipment Interaction object owns Locked -> Aim -> Spraying -> Extinguished transitions. Release returns to Aim. StateChanged, FireExtinguished and OnFireExtinguished expose one-shot progression/completion hooks. It listens to the existing PinRemoved event and placement/reset events.
- SIHFireHazard on the existing fire prefab owns normalized health, configurable accurate-spray duration, target geometry and fire effect fading. Extinguished / OnExtinguished are per-hazard completion hooks. StopEmitting leaves particles alive; the logical root is never destroyed by extinction.
- SIHHoldToSpray handles one pointer, release, drag-off, cancel, missing/cancelled touches, disable, focus loss and pause. It runs before damage updates. SIHUIInput explicitly raycasts the current uGUI at each touch to avoid Update-order-dependent input leaking to the world.
- SIHPowderSpray uses the existing nozzle/rim/aperture transforms at runtime without changing the equipment prefab. The hose joint stays fixed; the nozzle rotates toward the camera's centre-ray aim point. World-space powder uses a small soft sprite, no collisions, shadows or physics, and a 100-particle cap.
- The target is a disc parallel to the measured plane, 0.08 * Fire Size metres above it, radius 0.35 * Fire Size, with an 8 m maximum ray distance. At defaults it is 0.525 m in radius. Geometry is relative to the placed hazard and its recorded surface, never inferred from the camera image.
- Fire root scale is original .30 * Fire Size = .45. Equipment is placed at least max(1.25, .75 * Fire Size + .25) metres away; at default this is 1.375 m. Both fire and equipment AR placement still use TrackableType.Planes; equipment additionally validates a tracked upward horizontal polygon with enough base footprint.
- Fire uses copies of its original erosion materials with reduced emission, retaining original texture animation. Shared vendor materials are unchanged. Maximum particles are 64 for smoke systems, 40 for spark systems and 80 for other systems; only one particle light is allowed. Existing camera exposure, Depth Texture and AR Background Renderer Feature are unchanged.

## Validation

Unity compilation passed. Synthetic AR tests exercised original placement, grounding, selection, pin removal and the pre-pin spray lock. Runtime tests passed for Aim transition, base hit/miss, 1.5 size, nozzle direction, elapsed-time damage, no damage on misses/releases, button release/cancel/drag-off, focus/pause/disable, UI blocking, one completion per event channel, retained hazard root and reset. An extinction lifetime test retained 159 existing particles, then confirmed natural expiry, stopped audio, and restoration of full health/scale/emission by ResetFire.

Unity-rendered previews were actually inspected for flame detail, floor glow, equipment spacing and powder direction. A Game view capture was inspected for the prompt, centre reticle, hold button and reset button. These are desktop previews with a synthetic surface, not phone visual verification. No Android build, physical touch cancellation test, on-device AR depth/grounding test or device performance measurement has been performed.

Backups: Backups/AimSpray_* contains pre-change files and source iterations. Each setup run adds Backups/AimSpraySetup_* with the disk scene, live scene, prefab and any existing materials it changes.

Final preservation check: ProjectSettings.asset, both package files, Mobile_RPAsset, Mobile_Renderer, and the entire improved extinguisher prefab match the pre-change backup byte-for-byte. Serialized scene Camera components also match. Depth Texture and the active AR Background Renderer Feature remain enabled. Original AR preload entries were restored after Play testing. The current scene is saved and clean, with one aim controller, one equipment controller, one EventSystem and no missing scripts.

Final isolated preview: D:/AR/.utmp/powder-preview.png. Game view capture: D:/AR/.utmp/aim-spray-game.png (captured before the final reticle backing and powder density adjustment; yellow Editor background is the existing AR camera preview, not a live phone image).

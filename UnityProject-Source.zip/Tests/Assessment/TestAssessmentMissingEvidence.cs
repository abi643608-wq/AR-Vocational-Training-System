var recorder=UnityEngine.Object.FindFirstObjectByType<SIHAssessmentRecorder>();
var assessmentFlags=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
var testStore=new SIHAttemptStore("D:/AR/.utmp/AssessmentIntegration_"+System.Guid.NewGuid().ToString("N"));
typeof(SIHAssessmentRecorder).GetField("store",assessmentFlags).SetValue(recorder,testStore);
typeof(SIHAssessmentRecorder).GetField("focused",assessmentFlags).SetValue(recorder,true);
typeof(SIHAssessmentRecorder).GetField("paused",assessmentFlags).SetValue(recorder,false);
var routeTest=UnityEngine.Object.FindFirstObjectByType<SIHTrainingRoute>();
var routeTestFlags=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
var routeTestSession=typeof(UnityEngine.XR.ARFoundation.ARSession).GetField("s_State",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic);
routeTestSession.SetValue(null,UnityEngine.XR.ARFoundation.ARSessionState.SessionTracking);
typeof(SIHTrainingRoute).GetField("focused",routeTestFlags).SetValue(routeTest,true);
typeof(SIHTrainingRoute).GetField("paused",routeTestFlags).SetValue(routeTest,false);routeTest.ReconfigureRoute();var routeTestCamera=routeTest.Camera;var routeTestForward=UnityEngine.Vector3.ProjectOnPlane(routeTestCamera.transform.forward,UnityEngine.Vector3.up).normalized;
var routeTestExit=routeTestCamera.transform.position+routeTestForward*4-UnityEngine.Vector3.up*.5f;
routeTest.PlaceGroundMarker(SIHTrainingRoute.Kind.Exit,new UnityEngine.Pose(routeTestExit,UnityEngine.Quaternion.identity));
routeTest.PlaceGroundMarker(SIHTrainingRoute.Kind.Assembly,new UnityEngine.Pose(routeTestExit+routeTestCamera.transform.right*2,UnityEngine.Quaternion.identity));routeTest.Review();if(!routeTest.ConfirmRoute())throw new System.Exception("Restart route setup failed");
if(!UnityEngine.Application.isPlaying) throw new System.Exception("Run in Play mode");
var flags=System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic;
var placement=UnityEngine.Object.FindFirstObjectByType<ARPlacementController>();
var equipment=UnityEngine.Object.FindFirstObjectByType<SIHExtinguisherSelection>();
var manager=placement.GetComponent<UnityEngine.XR.ARFoundation.ARPlaneManager>();
var raycasts=placement.GetComponent<UnityEngine.XR.ARFoundation.ARRaycastManager>();
var stateField=typeof(UnityEngine.XR.ARFoundation.ARSession).GetField("s_State",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic);
var oldState=stateField.GetValue(null);
var camera=UnityEngine.Camera.main;
var forward=UnityEngine.Vector3.ProjectOnPlane(camera.transform.forward,UnityEngine.Vector3.up).normalized;
if(forward.sqrMagnitude<.1f)forward=UnityEngine.Vector3.forward;
var pose=new UnityEngine.Pose(camera.transform.position+forward*1.8f-UnityEngine.Vector3.up*.5f,UnityEngine.Quaternion.identity);
var findGround=typeof(SIHExtinguisherSelection).GetMethod("TryFindGround",flags);
System.Func<bool> canPlace=()=>{object[] args={pose,default(UnityEngine.Pose)};return (bool)findGround.Invoke(equipment,args);};
var planeObject=new UnityEngine.GameObject("Synthetic floor test only");
var plane=planeObject.AddComponent<UnityEngine.XR.ARFoundation.ARPlane>();
var id=new UnityEngine.XR.ARSubsystems.TrackableId(11111,22222);
var dictionary=(System.Collections.IDictionary)typeof(UnityEngine.XR.ARFoundation.ARPlaneManager).BaseType.GetField("m_Trackables",flags).GetValue(manager);
var setData=typeof(UnityEngine.XR.ARFoundation.ARPlane).BaseType.GetMethod("SetSessionRelativeData",flags);
System.Action<UnityEngine.XR.ARSubsystems.PlaneAlignment,UnityEngine.XR.ARSubsystems.TrackingState> setPlane=(alignment,tracking)=>setData.Invoke(plane,new object[]{new UnityEngine.XR.ARSubsystems.BoundedPlane(id,UnityEngine.XR.ARSubsystems.TrackableId.invalidId,pose,UnityEngine.Vector2.zero,new UnityEngine.Vector2(4,4),alignment,tracking,System.IntPtr.Zero,UnityEngine.XR.ARSubsystems.PlaneClassifications.Floor)});
int events=0;System.Action<SIHExtinguisher> callback=_=>events++;
try
{
    stateField.SetValue(null,UnityEngine.XR.ARFoundation.ARSessionState.SessionTracking);
    typeof(UnityEngine.XR.ARFoundation.ARRaycastManager).GetMethod("RegisterRaycaster",flags).Invoke(raycasts,new object[]{manager});
    if(canPlace())throw new System.Exception("Unmapped ground accepted");
    planeObject.transform.SetPositionAndRotation(pose.position,pose.rotation);
    var boundary=new Unity.Collections.NativeArray<UnityEngine.Vector2>(new[]{new UnityEngine.Vector2(-2,-2),new UnityEngine.Vector2(2,-2),new UnityEngine.Vector2(2,2),new UnityEngine.Vector2(-2,2)},Unity.Collections.Allocator.Persistent);
    typeof(UnityEngine.XR.ARFoundation.ARPlane).GetField("m_Boundary",flags).SetValue(plane,boundary);
    dictionary.Add(id,plane);
    setPlane(UnityEngine.XR.ARSubsystems.PlaneAlignment.Vertical,UnityEngine.XR.ARSubsystems.TrackingState.Tracking);
    if(canPlace())throw new System.Exception("Vertical alignment accepted");
    setPlane(UnityEngine.XR.ARSubsystems.PlaneAlignment.HorizontalDown,UnityEngine.XR.ARSubsystems.TrackingState.Tracking);
    if(canPlace())throw new System.Exception("Downward plane accepted");
    setPlane(UnityEngine.XR.ARSubsystems.PlaneAlignment.HorizontalUp,UnityEngine.XR.ARSubsystems.TrackingState.Limited);
    if(canPlace())throw new System.Exception("Limited tracking accepted");
    setPlane(UnityEngine.XR.ARSubsystems.PlaneAlignment.HorizontalUp,UnityEngine.XR.ARSubsystems.TrackingState.Tracking);
    plane.transform.rotation=UnityEngine.Quaternion.Euler(20,0,0);
    if(canPlace())throw new System.Exception("Tilted surface accepted");
    plane.transform.rotation=UnityEngine.Quaternion.identity;
    plane.transform.position=pose.position+UnityEngine.Vector3.up*.2f;
    if(canPlace())throw new System.Exception("Different elevation accepted");
    plane.transform.position=pose.position;
    if(!canPlace())throw new System.Exception("Valid floor rejected");
    for(int i=0;i<boundary.Length;i++)boundary[i]*=.1f;
    if(canPlace())throw new System.Exception("Infinite plane extension accepted");
    for(int i=0;i<boundary.Length;i++)boundary[i]*=10f;
    var prefab=(UnityEngine.GameObject)typeof(ARPlacementController).GetField("placementPrefab",flags).GetValue(placement);
    var fire=UnityEngine.Object.Instantiate(prefab,pose.position+UnityEngine.Vector3.up*.08f,pose.rotation);
    typeof(ARPlacementController).GetField("spawnedObject",flags).SetValue(placement,fire);
    typeof(ARPlacementController).GetField("hasPlacedObject",flags).SetValue(placement,true);
    typeof(ARPlacementController).GetProperty("PlacementSurfacePose").SetValue(placement,pose);
    var placed=(System.Action<UnityEngine.Pose>)typeof(ARPlacementController).GetField("Placed",flags).GetValue(placement);
    placed(pose);
    var instance=equipment.SpawnedExtinguisher;
    if(instance==null||UnityEngine.Mathf.Abs(instance.transform.position.y-pose.position.y)>.001f)throw new System.Exception("Equipment not grounded");
    placed(pose);if(equipment.SpawnedExtinguisher!=instance)throw new System.Exception("Duplicate spawned");
    if(equipment.TrySelect(camera.WorldToScreenPoint(instance.SelectionCollider.bounds.center)))throw new System.Exception("Placing gesture not consumed");
    // Explicitly simulate the next no-touch frame; actual device touch remains a phone check.
    typeof(SIHExtinguisherSelection).GetField("spawnFrame",flags).SetValue(equipment,UnityEngine.Time.frameCount-1);
    typeof(SIHExtinguisherSelection).GetMethod("Update",flags).Invoke(equipment,null);
    equipment.ExtinguisherSelected+=callback;
    var screen=camera.WorldToScreenPoint(instance.SelectionCollider.bounds.center);
    if(!equipment.TrySelect(screen)||equipment.TrySelect(screen)||events!=1)throw new System.Exception("Selection/event guard failed");
    if(equipment.TryRemovePin(camera.WorldToScreenPoint(equipment.SafetyPin.TargetPosition)))throw new System.Exception("Selection gesture removed pin");
    typeof(SIHExtinguisherSelection).GetField("spawnFrame",flags).SetValue(equipment,UnityEngine.Time.frameCount-1);
    typeof(SIHExtinguisherSelection).GetMethod("Update",flags).Invoke(equipment,null);
    if(equipment.TryRemovePin(new UnityEngine.Vector2(-10000,-10000)))throw new System.Exception("Miss removed pin");
    UnityEditor.SessionState.SetInt("SIH.PinTestEvents",0);
    UnityEditor.SessionState.SetInt("SIH.PinTestInspectorEvents",0);
    equipment.PinRemoved += _ => UnityEditor.SessionState.SetInt("SIH.PinTestEvents",UnityEditor.SessionState.GetInt("SIH.PinTestEvents",0)+1);
    equipment.OnPinRemoved.AddListener(()=>UnityEditor.SessionState.SetInt("SIH.PinTestInspectorEvents",UnityEditor.SessionState.GetInt("SIH.PinTestInspectorEvents",0)+1));
    if(UnityEngine.Object.FindFirstObjectByType<SIHAimSprayController>().BeginSpray())throw new System.Exception("Spray allowed before pin removed");
    var ringScreen=camera.WorldToScreenPoint(equipment.SafetyPin.TargetPosition);
    if(!equipment.TryRemovePin(ringScreen))throw new System.Exception("Ring tap failed");
    if(!equipment.SafetyPin.IsRemoving || equipment.TryRemovePin(ringScreen))throw new System.Exception("Repeated pull accepted");
    UnityEngine.Application.runInBackground=true;
    UnityEditor.EditorApplication.isPaused=false;
    // Complete the actual pin coroutine synchronously; this remains a simulated input/clock test.
    equipment.SafetyPin.StopAllCoroutines();
    var extraction=(System.Collections.IEnumerator)typeof(SIHSafetyPin).GetMethod("RemovePin",flags).Invoke(equipment.SafetyPin,null);
    int guard=0;while(extraction.MoveNext()){if(++guard>10000)throw new System.Exception("Pin coroutine did not finish");}
    if(!recorder.Current.pinRemovedCorrectly||recorder.Current.Item("pin").earned!=20)throw new System.Exception("Real pin sequence not recorded");
    var controller=UnityEngine.Object.FindFirstObjectByType<SIHAimSprayController>();
    typeof(SIHAimSprayController).GetField("focused",flags).SetValue(controller,true);typeof(SIHAimSprayController).GetField("paused",flags).SetValue(controller,false);
    controller.Sweep.enabled=false;
    var controllerUpdate=typeof(SIHAimSprayController).GetMethod("Update",flags);
    var recorderUpdate=typeof(SIHAssessmentRecorder).GetMethod("Update",flags);
    float dt=UnityEngine.Time.unscaledDeltaTime;if(dt<=0||dt>.25f)throw new System.Exception("Synthetic test requires a normal Editor frame time: "+dt);
    var originalRotation=camera.transform.rotation;
    camera.transform.rotation=UnityEngine.Quaternion.LookRotation(UnityEngine.Vector3.up);
    if(!controller.BeginSpray())throw new System.Exception("Spray did not start after pin");
    for(int i=0;i<UnityEngine.Mathf.CeilToInt(1.2f/dt);i++){controllerUpdate.Invoke(controller,null);recorderUpdate.Invoke(recorder,null);}
    if(recorder.Current.validAimSpraySeconds!=0||recorder.Current.mistakes.Count!=1)throw new System.Exception("Off-target action evidence incorrect");
    controller.StopSpray();double priorDuration=recorder.Current.activeSeconds;
    typeof(SIHAssessmentRecorder).GetMethod("OnApplicationPause",flags).Invoke(recorder,new object[]{true});
    for(int i=0;i<50;i++)recorderUpdate.Invoke(recorder,null);
    if(recorder.Current.activeSeconds!=priorDuration||recorder.Current.mistakes.Count!=1)throw new System.Exception("Suspension counted time/mistake");
    typeof(SIHAssessmentRecorder).GetMethod("OnApplicationPause",flags).Invoke(recorder,new object[]{false});
    stateField.SetValue(null,UnityEngine.XR.ARFoundation.ARSessionState.SessionInitializing);
    for(int i=0;i<50;i++)recorderUpdate.Invoke(recorder,null);
    if(recorder.Current.activeSeconds!=priorDuration||recorder.Current.mistakes.Count!=1)throw new System.Exception("Tracking loss counted time/mistake");
    stateField.SetValue(null,UnityEngine.XR.ARFoundation.ARSessionState.SessionTracking);
    var left=controller.Sweep.LeftEndpoint;var right=controller.Sweep.RightEndpoint;
    camera.transform.LookAt(UnityEngine.Vector3.Lerp(left,right,.08f));
    if(!controller.BeginSpray())throw new System.Exception("Spray did not resume");
    int steps=UnityEngine.Mathf.CeilToInt(1.7f/dt);
    for(int pass=0;pass<2;pass++)for(int i=0;i<steps;i++){
        float t=UnityEngine.Mathf.Lerp(.08f,.92f,i/(float)(steps-1));if(pass==1)t=1-t;
        camera.transform.LookAt(UnityEngine.Vector3.Lerp(left,right,t));controllerUpdate.Invoke(controller,null);recorderUpdate.Invoke(recorder,null);
    }
    guard=0;while(!controller.Hazard.IsExtinguished){controllerUpdate.Invoke(controller,null);recorderUpdate.Invoke(recorder,null);if(++guard>10000)throw new System.Exception("Fire never extinguished");}
    if(!recorder.Current.fireExtinguished||recorder.Current.sweepPasses!=0||recorder.Current.Item("aim").earned!=20)throw new System.Exception("Spray/sweep/fire evidence missing: "+UnityEngine.JsonUtility.ToJson(recorder.Current));
    UnityEngine.Physics.SyncTransforms();var exitMarker=UnityEngine.Object.FindObjectsByType<SIHRouteMarker>(UnityEngine.FindObjectsSortMode.None).OrderBy(m=>UnityEngine.Vector3.Distance(m.transform.position,routeTestExit)).First();
    camera.transform.LookAt(exitMarker.SelectionCollider.bounds.center);
    if(!routeTest.IdentifyExit(camera.WorldToScreenPoint(exitMarker.SelectionCollider.bounds.center)))throw new System.Exception("Exit not identified");
    if(!recorder.Current.exitIdentified||recorder.Current.routeStops!=0)throw new System.Exception("Selection falsely counted arrival");
    System.Action<UnityEngine.Vector3,int> hold=(point,count)=>{for(int i=0;i<count;i++)routeTest.ProcessArrival(point+UnityEngine.Vector3.up*1.6f,true,1f/60);};
    System.Action<UnityEngine.Vector3,UnityEngine.Vector3> walk=(a,b)=>{for(int i=1;i<=240;i++)hold(UnityEngine.Vector3.Lerp(a,b,i/240f),1);};
    var start=routeTestExit-routeTestForward*2;var assembly=routeTestExit+routeTestCamera.transform.right*2;
    // Use stored endpoint, since camera was rotated during aiming.
    assembly=(UnityEngine.Vector3)typeof(SIHTrainingRoute).GetMethod("World",flags).Invoke(routeTest,new object[]{1});
    hold(start,150);walk(start,routeTestExit);hold(routeTestExit,100);hold(routeTestExit,150);walk(routeTestExit,assembly);hold(assembly,150);
    var completed=recorder.LastResult;
    if(completed==null||completed.earnedPoints!=80||completed.availablePoints!=80||completed.outcome!="Assessment incomplete"||completed.routeStops!=2||!recorder.ShowingResults)throw new System.Exception("Full attempt result incorrect: "+UnityEngine.JsonUtility.ToJson(recorder.Current));
    var saved=System.IO.File.ReadAllText(System.IO.Path.Combine(testStore.DirectoryPath,completed.attemptId+".json"));
    ((System.Action)typeof(SIHTrainingRoute).GetField("AssemblyReached",flags).GetValue(routeTest))?.Invoke();
    ((System.Action)typeof(SIHAimSprayController).GetField("FireExtinguished",flags).GetValue(controller))?.Invoke();
    if(testStore.LoadHistory().Count!=1||System.IO.File.ReadAllText(System.IO.Path.Combine(testStore.DirectoryPath,completed.attemptId+".json"))!=saved)throw new System.Exception("Duplicate completion changed final save");
    // Keep the completed record for a separate screen preview before restarting.
    UnityEditor.SessionState.SetString("SIH.AssessmentTestResult",UnityEngine.JsonUtility.ToJson(completed));
    routeTest.RestartExercise();if(!recorder.Running||recorder.Current.attemptId==completed.attemptId||recorder.Current.earnedPoints!=0||recorder.Current.validAimSpraySeconds!=0||recorder.Current.mistakes.Count!=0)throw new System.Exception("Restart carried score over");
    var interruptedId=recorder.Current.attemptId;routeTest.ReconfigureRoute();if(testStore.LoadHistory().Count!=2||!testStore.LoadHistory().Any(r=>r.attemptId==interruptedId&&r.outcome=="Incomplete"&&r.status=="Interrupted"))throw new System.Exception("Interrupted attempt not saved/history lost");
    controller.Sweep.enabled=true;camera.transform.rotation=originalRotation;
    return new{result="PASS: actual selection and pin events, measured held-spray aim, disabled sweep evidence source, fire event, exit/ordered arrival events, missing sweep source excluded: 80/80 Assessment incomplete, tracking and suspension clock pause, duplicate final save, fresh restart ID and interrupted history",path=testStore.DirectoryPath};

}
finally
{
    UnityEngine.Object.FindFirstObjectByType<SIHSweepAssessment>().enabled=true;equipment.ExtinguisherSelected-=callback;

    dictionary.Remove(id);
    UnityEngine.Object.DestroyImmediate(planeObject);
    stateField.SetValue(null,oldState);
}








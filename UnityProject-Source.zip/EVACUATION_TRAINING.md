# Training route and evacuation prototype

Implemented in the current `Assets/Scenes/ARTraining.unity`. The working scene and all existing files changed for this stage were backed up in `Backups/Evacuation_20260927_091822`. Each use of the setup command also backs up the saved scene and the live scene under `Backups/RouteSetup_*` before changing it.

## Unity setup and Android build

1. Open `D:\AR` in Unity 6000.3.24f1. Open `Assets/Scenes/ARTraining.unity` and wait for compilation.
2. The scene is already wired. To repair/reapply the route UI wiring, leave Play mode and run **Tools > SIH > Setup Training Route**. This reuses the existing training controller, Canvas and components. It does not replace the scene or change the fire/extinguisher prefabs.
3. Select **SIH Equipment Interaction**. `SIH Route Arrival` exposes Arrival Radius (0.65 m), Dwell Seconds (1.25 s), Stable Tracking Seconds (1.5 s), Leave Margin (0.2 m), Maximum Step (0.65 m), Maximum Speed (3 m/s), and Maximum Sample Gap (0.3 s). `SIH Training Route` exposes Spacing Margin (0.3 m), Ground Height Tolerance (0.15 m), and completion UnityEvents.
4. Open **File > Build Profiles**, select the existing Android profile, and ensure `Assets/Scenes/ARTraining.unity` is included/enabled in its scene list. Keep the existing graphics, XR, camera and renderer settings. Connect the Android device with USB debugging enabled, select it as Run Device, then **Build And Run**. Use a new APK output name for this version.

## Configure a route on the phone

The demonstrator must configure the route before fire placement. These are manually chosen training locations, not automatically detected exits or verified emergency routes. There is no obstacle avoidance or safe-route discovery.

1. Scan a sufficiently large, upward-facing horizontal floor. Tap **PLACE EXIT**, then tap the detected floor at the intended training exit location.
2. Tap **+ WAYPOINT**, then tap the floor for each intermediate turn, in order. Tap **ASSEMBLY**, then its intended floor location. A green exit sign, amber numbered waypoint signs and a blue assembly sign identify the locations. Direction arrows connect each consecutive segment.
3. Keep markers at least 1.6 m apart with the default settings. This keeps their arrival areas separate. This prototype accepts only markers at approximately the same ground level; it is not a stairs/multifloor route.
4. Review the signs, arrows and displayed order. **SELECT NEXT** cycles through markers; tapping a sign also selects it when no placement tool is active. **MOVE** followed by a floor tap moves the selected marker. **DELETE** removes it. **EARLIER/LATER** reorder selected intermediate waypoints without moving the exit or assembly endpoints. Selecting a placement tool exits review.
5. Tap **REVIEW**. Step outside every marker's starting exclusion radius (0.95 m by default), then tap **CONFIRM & START**. Missing endpoints, unreviewed routes, overlapping arrival areas and starting inside a marker radius cannot start the exercise.
6. Place the fire and use the existing extinguisher selection, safety-pin, aiming and spray controls. Route setup never automatically positions a destination relative to the phone.

Route coordinates exist only in memory under the current XR trackables coordinate frame. Restarting the exercise keeps them only within the valid session. A new/replaced session or changed ARCore session identity clears them and requires setup again. Closing/relaunching the app does not restore raw coordinates. Some pause/resume operations can restart ARCore and therefore require route setup again.

## Evacuation behavior

After the fire-extinguished event, spray stops and its controls hide. Fire and sweep results remain recorded. The prompt becomes **Find and select the training exit**. Tap the green sign to identify it; this records identification, not arrival.

Walk to the exit ground marker, then each numbered waypoint, then assembly. The display shows distance to the next required stop and an off-screen direction indicator. It does not advance to later waypoints because they are closer or were tapped. Follow the configured turns.

Arrival uses the AR camera position projected onto the route ground plane. After stable tracking, the detector must observe you outside the current radius plus leave margin (0.85 m default), then inside the 0.65 m radius for 1.25 seconds. If you selected the exit while already standing inside it, step outside and approach again. This rule also applies after tracking recovery.

Tracking loss pauses detection. Tracking must recover and remain stable for 1.5 seconds. Large position/speed jumps and long sample gaps discard the partial approach; they do not award an arrival or record a trainee mistake. This is a conservative jump guard, not a guarantee against all AR drift.

At assembly the prompt is **Assembly point reached — training scenario complete.** Exit identification, ordered route completion and assembly completion are separate results. Sweep completion is displayed as complete or not demonstrated; an incomplete sweep never blocks evacuation.

**RESTART EXERCISE** restores the fire at its already measured placement pose, with full configured health/visuals and fresh extinguisher, pin, selection and sweep state. It clears evacuation results but keeps the confirmed route in the valid session. If no fire was placed yet, normal fire placement remains available.

**RECONFIGURE ROUTE** clears the exercise and all route markers/results and returns to route setup. It does not reset or disable AR tracking.

## Integration and events

The existing `SIHAimSprayController.TrainingState` now includes `RouteSetup`, `FindExit`, `Evacuate` and `ScenarioComplete`; existing enum values are preserved. `SIHTrainingRoute` consumes the existing fire-extinguished and placement-reset events. There is no second training-state manager.

- `ExitIdentificationCompleted` / `OnExitIdentified`: one event after selecting the exit.
- `WaypointReached(int)`: once for each ordered physical stop (zero is the exit; the last index is assembly).
- `RouteCompleted` / `OnRouteCompleted`: once after the complete ordered route.
- `AssemblyReached` / `OnAssemblyReached`: once on final arrival.
- Separate result properties retain exit identification, reached count, ordered route completion, assembly completion, fire extinction, sweep completion and sweep pass count until restart/reconfiguration.

`SIHRouteArrival` owns approach/dwell validation. `SIHRouteMarker` owns sign visuals. `SIHRouteUI` owns route feedback. Placement and equipment logic remain separate. No certificate or scoring formula is implemented.

## Android acceptance checklist

1. **Missing/unconfirmed route:** try Review/Confirm with no exit, no assembly and before Review. Fire placement must remain unavailable. Try overlapping markers and a vertical wall; placement must be rejected. Try confirming while inside an endpoint radius; step away to proceed.
2. **Edit/review:** create a route with at least two turns. Move a marker, swap waypoint order, delete/re-add one, review and confirm. Check signs, arrows and order agree. UI taps must not place fire, place a marker or select equipment behind them.
3. **Existing exercise:** select the extinguisher, remove the pin, aim/spray and release. Confirm the existing miss, release and gradual-extinction behavior. Finish once with 2/2 sweeps and once without complete sweep credit; both must enter FindExit and retain the correct sweep result.
4. **Identification versus arrival:** tap a waypoint or assembly first; neither identifies the exit. Tap the green exit from outside its arrival radius. The prompt should enter evacuation, but the reached-stop count must still be zero. Physically approach and dwell to reach the exit.
5. **Ordered route:** walk toward a later waypoint/assembly before the required one. No later stop should receive credit. Return and follow exit > waypoint 1 > waypoint 2 > assembly. Check next distance and turn indicators, including with the next marker behind the camera.
6. **Tracking:** cover the camera/lose tracking during approach or dwell. Expect Tracking paused and no arrival. Uncover and wait for stable tracking. If already inside the target, step outside then approach again. If ARCore starts a new session, expect route invalidation and setup instead of reuse of old coordinates. Check a relocalization jump cannot complete a stop.
7. **Completion:** dwell at assembly after all prior stops. Check the exact completion prompt, all stops recorded and separate exit/sweep results. Keep standing there and tap signs: completion must not repeat.
8. **Restart:** restart from completion and midway through evacuation. Confirm route remains, original fire location returns at full health/size, fresh extinguisher and attached pin appear, selection/sweep/route results clear, and another complete attempt works.
9. **Reconfigure:** reconfigure during an exercise or after completion. Confirm old fire, equipment and route markers clear and new route setup is required. Relaunch the app and verify no old raw coordinates are reused.

## Validation performed

- Unity compilation completed without compiler errors.
- Live Editor scene wiring verified; setup rerun preserved object count, existing controller reference and exactly one persistent callback per route button.
- Synthetic Play mode tests passed: missing/unreviewed route rejection; upward-surface/spacing and starting-radius checks; reorder/move/delete; route-button UI raycasts; actual placed-fire extinction event transition; incomplete sweep retention; identification separate from arrival; out-of-order rejection; tracking pause/recovery and jump rejection; ordered arrivals; single completion events; restart restoring fire/equipment/pin/health/selection/sweep; reconfiguration and session invalidation.
- Isolated Unity-rendered marker preview inspected and label wrapping corrected. Existing Game view route setup UI was previewed. These are Editor previews, not phone-camera visual verification.
- Protected renderer/settings assets, all existing prefabs, package files and ProjectSettings compare unchanged against the pre-task backup. Camera serialization in the working scene is unchanged. Fire and route raycasts retain `TrackableType.Planes`; hiding plane renderers does not disable tracking.
- No Android APK build or physical-device run was performed. Real ARCore plane placement, drift/relocalization, physical distances/dwell, mobile touch layout/readability and device performance still require the checklist above. Synthetic tests cannot establish real-world route safety.

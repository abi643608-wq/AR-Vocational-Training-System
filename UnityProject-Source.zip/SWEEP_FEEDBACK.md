# Sweep feedback update

The current ARTraining scene includes projected L/R endpoint markers at the captured fire-base target edges, a Sweep passes: 0/2 counter, and a green numbered DONE badge for each credited pass. Required pass count follows the existing Inspector setting. Counter/highlights remain after extinction until Reset; endpoint markers hide on tracking loss, when behind/offscreen, and after extinction. They do not receive UI raycasts or interfere with placement/spraying.

Endpoint positions come from SIHSweepAssessment's captured target frame and diameter, not particle bounds. Health only changes particle size/emission; target and marker width remain stable. Normalized hit X is -0.5 at L, 0 at centre and +0.5 at R. Reversal/travel thresholds were not lowered.

Development display: enable Show Development Diagnostics on the Sweep Feedback object's SIHSweepFeedback. It displays valid aim, spray and tracking flags, raw normalized hit X, smoothed X, current direction, credited/required passes and the current sampling status. It is compiled for UNITY_EDITOR or DEVELOPMENT_BUILD only and forcibly hidden in ordinary release builds. Invalid aim and stopped spraying break the partial segment; diagnostics help distinguish these from insufficient travel or hit jumps. Smoothing affects assessment only.

Duration remains configurable on Assets/Prefabs/Fire/FireHazard.prefab > SIHFireHazard > Required Spray Seconds. The existing default remains 5 seconds to preserve health behaviour. Its tooltip now explicitly says it is independent of sweep completion. For slower practice, increase it (for example to 7–8 seconds) and rebuild; do not change sweep thresholds merely because the fire went out early.

Measured deterministic tests used continuous valid motion between normalized -0.42 and +0.42 with the current smoothing and travel thresholds:

- 1.5 seconds per pass: two passes credited at 2.62 seconds.
- 2 seconds per pass: two passes credited at 3.43 seconds, within the 5-second budget.
- 3 seconds per pass: only one credited before extinction at 5 seconds.

These are prototype simulation results, not guarantees of user timing or an official training standard. Fire can still extinguish without sweep completion and reports that sweep technique was not demonstrated. No automatic reignition or sweep prerequisite was added.

Validation: compilation and prior sweep regression cases passed. Endpoint coordinates remained unchanged throughout simulated health reduction. Game-view screenshots were inspected for zero-pass display, projected endpoints, development diagnostics and the green first-pass badge. The initial screenshot exposed debug-panel overlap; its layout was moved above the reticle. No phone build/test or release-build visual check was performed.

Unity steps: open ARTraining. Wiring is already saved. Tools > SIH > Setup Sweep Assessment repairs/reapplies feedback and backs up the scene. Setup Aim and Spray also preserves this wiring. Tuning values remain on SIHSweepAssessment; duration is on the FireHazard prefab.

Android check: Build Profiles > Android > enable Development Build > Build And Run. Place/select/remove pin. Verify L/R span the base and remain fixed as health falls. Sweep while holding: observe valid aim, normalized X moving between the endpoint values, direction reversal and a green badge for each completed pass. Release or miss and confirm the partial segment restarts. Reset should clear highlights/progress. Try 2-second passes with the default duration, then increase Required Spray Seconds for slower trials. Finally build with Development Build off and confirm the diagnostic panel is absent while endpoints/counter remain visible.

Backups: Backups/SweepFeedback_* and per-run Backups/SweepSetup_*. Test: .utmp/TestFeedbackDuration.cs.

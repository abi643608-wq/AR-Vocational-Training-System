# Detailed extinguisher — Unity AR training

The current `Assets/Prefabs/Equipment/SIHExtinguisher.prefab` has been updated in place. Its root, asset GUID, SIHExtinguisher component and BoxCollider component are retained. Scene references and selection events are preserved.

## Model and material design

No existing extinguisher type configuration or suitable detailed mesh was found. The model uses one consistent stored-pressure dry-powder design: a red pressure vessel, small pressure gauge, fixed carry handle, separate squeeze lever, safety pin, pull ring, curved rubber hose and narrow nozzle. There is no CO2 horn or foam applicator. This is a generic training model, with no manufacturer branding, certification or hazard-rating claims. Proportion reference: https://www.jactone.com/wp-content/uploads/2025/04/Jactone_Fire-Safety-Equipment_Catalogue_25Rev0_pg15.pdf

- Height: 0.559124 m; vessel diameter: 0.168 m.
- Geometry: 4,847 vertices / 7,976 triangles, including the thin 3 mm selection ring. Rounded lathed vessel/shoulders/bottom, swept elliptical handles and tube hose; no primitive block rebuild.
- The contact foot's lowest point is local Y=0. The rounded vessel bottom is supported by that foot.
- Safety Pin and Pull Ring remain separate named transforms. After selecting the extinguisher and releasing the touch, tap the highlighted ring to extract both parts over 0.65 seconds. Spraying is not implemented.
- Label follows the vessel at radius 0.0846 m, only 0.6 mm outside the painted surface.
- All materials use URP Lit: moderate paint smoothness, metallic steel/brass, matte rubber, nonmetal label. The existing scene lighting remains unchanged. Equipment-only environment reflections are disabled to remove preview speckles; direct-light specular highlights and metallic shading remain enabled.
- Two small generated textures: 512 x 512 label and 128 x 128 gauge, with mipmaps and Android ETC2 RGB compression for OpenGLES3. Meshes and materials are shared assets, not generated at runtime.

## Generator / setup

**Tools > SIH > Rebuild Detailed Extinguisher** backs up every existing prefab/material/mesh/texture it edits, then rebuilds this appearance. The older **Use Supplied Extinguisher Model** command now forwards to the detailed builder. **Setup Extinguisher Selection** reuses the current prefab and uses the detailed builder if creation is needed. The blocky fallback generator has been removed.

Model source: `Assets/Editor/SIHRealisticExtinguisherModel.cs`.

## Grounding behavior

Fire placement is unchanged and still raycasts with `TrackableType.Planes`; its 0.08 m clearance is still fire-only.

Equipment now casts a separate downward AR ray at the candidate position beside the fire, also using `TrackableType.Planes`. It accepts only a currently tracked `HorizontalUp` plane with an upward normal within 10 degrees, a polygon hit, a complete 9 cm radius base footprint within the detected boundary, and a surface height within 12 cm of the original placement surface. It tries the right and left side, 0.75 m from the fire.

If neither side has valid measured floor, no floating placeholder is spawned. The prompt asks you to scan more floor beside the fire, and equipment placement retries twice per second. This uses AR plane geometry, never the camera image or an infinite-plane guess. After one valid spawn, taps cannot relocate it or create another one. The placing gesture must be released before selection.

A detected plane is an AR estimate, not exact physical ground truth. Real-world alignment, tracking drift and different floor textures must be checked on a phone.

## Unity and phone steps

1. Open `D:/AR` with Unity 6000.3.24f1 and open `Assets/Scenes/ARTraining.unity`. The prefab update is already applied; no setup command is required.
2. Wait for compilation and check Console for errors. To deliberately regenerate the model later, choose **Tools > SIH > Rebuild Detailed Extinguisher**.
3. Open **File > Build Profiles**, select the existing Android profile and verify ARTraining remains enabled in its scene list. Connect the ARCore phone with USB debugging, select it under Run Device, then **Build And Run**. Keep OpenGLES3, Depth Texture, AR Background Renderer Feature and camera settings as they are.
4. Grant camera permission. Scan a broad, well-lit textured floor, then tap once to place the fire. Scan at least 0.9 m to either side if the app asks for more floor. Confirm exactly one extinguisher appears and the contact foot touches the measured floor without inheriting the fire's clearance.
5. View from a low angle and walk around the model: check curved bottom/shoulders, handle gap, separate ring/pin, hose, flush curved label and painted/metal/rubber lighting. Confirm apparent height is about 56 cm. Check the base on several detected floor patches.
6. Release the placing finger and tap the extinguisher. Confirm a thin gold ring and “Extinguisher selected”. Release your finger, then tap the highlighted pull ring. Confirm extraction followed by “Safety pin removed — step complete”. Repeated taps and taps elsewhere must not move the fire/equipment, repeat selection, or repeat pin removal.
7. Try placing fire near the edge of a mapped patch: equipment should wait until enough floor is scanned, rather than float over an unmeasured area. Do not use a wall or ceiling as equipment support.
8. In Editor Play mode, XR Origin > ARPlacementController component context menu > **Reset Placement** clears the fire, equipment and selection. No on-phone reset UI was added; restart the app for a clean device session.

## Backups and scope

Pre-change backup: `Backups/RealisticExtinguisher_20260926_074055`.
Each rebuild creates an additional `Backups/DetailedExtinguisher_*` folder. Existing scene, fire prefab/effects, Cube test prefab, renderer features, camera, packages and Android settings are preserved. No spraying, extinguishing, scoring or certified training behavior was added.

No screenshot was attached to the improvement request, so the diagnosis used the current assets and the described symptoms.

## Validation status and remaining work

Unity compilation passed. Mesh checks confirmed the stated height, base Y=0, triangle count and no inverted faces. Collider ray and highlight checks passed. Synthetic AR-plane tests rejected unmapped, vertical, downward, tilted, limited-tracking, different-elevation and infinite-plane-extension cases; accepted a valid floor; and verified grounded spawning, duplicate prevention, placement-touch consumption, one-shot selection and reset. Rerunning setup retained the detailed mesh and exactly one controller.

Safety-pin Play mode tests passed: separate selection/removal gestures, missed and repeated taps, animation completion, exactly one C# event and UnityEvent, placement reset, fresh instance state, and cancellation without completion notification. The saved prefab now has configured SIHSafetyPin references. Setup repairs missing references; the detailed generator wires them on every rebuild. Future TrainingManager code can subscribe to SIHExtinguisherSelection.PinRemoved or its OnPinRemoved UnityEvent.

Preview speckles were isolated with temporary material comparisons and removed by disabling equipment environment reflections only. URP Lit direct specular, metallic values and global scene/camera settings are preserved. The original Android XR settings and two ARCore background shaders were restored to preloaded assets after Play tests. ProjectSettings.asset matched its original backup byte-for-byte, as did the working scene, fire placement script, Mobile renderer/pipeline and package manifest.

Additional colliders already present on the prefab were retained. Selection still explicitly uses the original root BoxCollider; pin interaction uses its own ray target tolerance.

Backups for this continuation are in Backups/PinCompletion_*, Backups/PinWiring_*, and Backups/EquipmentReflectionFix_*. The earlier safety-pin source backup is Backups/SafetyPin_20260926_200050.

No Android build or physical-phone test has been performed. Real touch accuracy, AR grounding/tracking drift and device lighting/performance still need the phone checks above. No spraying, extinguishing or scoring was added.

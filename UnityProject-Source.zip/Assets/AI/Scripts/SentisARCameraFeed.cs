using System;
using System.Collections;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

/// <summary>ARCore CPU-image source only. Detection stays in SentisModelTester.</summary>
[DisallowMultipleComponent]
public sealed class SentisARCameraFeed : MonoBehaviour
{
    [SerializeField] private ARCameraManager cameraManager;
    [SerializeField] private SentisModelTester detector;
    [SerializeField, Min(.1f)] private float inferenceInterval=.5f;
    [SerializeField, Range(320,1280)] private int maximumImageSide=640;
    private bool busy,focused=true,paused;
    private float nextInference,nextWarning,lastFrame;
    private Coroutine pending;
    private XRCpuImage.AsyncConversion conversion;
    private bool ownsConversion;
    private Texture2D rawTexture,displayTexture;

    private void OnEnable()
    {
        if(gameObject.scene.name!="ARTraining_AI_Test" || cameraManager==null || detector==null)
        {Debug.LogWarning("Live YOLO: requires the AI test scene, existing ARCameraManager and SentisModelTester.",this);enabled=false;return;}
        cameraManager.frameReceived+=OnFrame;
        nextInference=0;lastFrame=Time.unscaledTime;
    }
    private void OnFrame(ARCameraFrameEventArgs frame)
    {
        lastFrame=Time.unscaledTime;
        if(!focused||paused||busy||detector.IsBusy||!detector.isActiveAndEnabled||Time.unscaledTime<nextInference)return;
        nextInference=Time.unscaledTime+Mathf.Max(.1f,inferenceInterval);
        if(!frame.displayMatrix.HasValue){Warn("waiting for camera display matrix; frame skipped");return;}
        if(!TryAcquire(out var image))return;
        try
        {
            if(!image.FormatSupported(TextureFormat.RGBA32)){Warn("device does not support RGBA32 CPU-image conversion");return;}
            float scale=Mathf.Min(1f,(float)maximumImageSide/Mathf.Max(image.width,image.height));
            var dimensions=new Vector2Int(Mathf.Max(1,Mathf.RoundToInt(image.width*scale)),Mathf.Max(1,Mathf.RoundToInt(image.height*scale)));
            conversion=image.ConvertAsync(new XRCpuImage.ConversionParams{
                inputRect=new RectInt(0,0,image.width,image.height),outputDimensions=dimensions,
                outputFormat=TextureFormat.RGBA32,transformation=XRCpuImage.Transformation.None});
            ownsConversion=true;busy=true;
            // Capture orientation/aspect with this image; never reuse a previous orientation matrix.
            pending=StartCoroutine(Process(frame.displayMatrix.Value,dimensions,new Vector2Int(Screen.width,Screen.height),Screen.orientation));
        }
        catch(Exception e){CancelPending();Warn("CPU-image acquisition/conversion failed: "+e.Message);}
        finally{image.Dispose();}
    }
    private bool TryAcquire(out XRCpuImage image)
    {
        image=default;
        try
        {
            if(cameraManager.TryAcquireLatestCpuImage(out image))return true;
            Warn("CPU camera image unavailable; check camera permission and device CPU-image support");
        }
        catch(Exception e){image.Dispose();Warn("CPU-image path unsupported/unavailable: "+e.Message);}
        return false;
    }
    private IEnumerator Process(Matrix4x4 matrix,Vector2Int dimensions,Vector2Int screen,ScreenOrientation orientation)
    {
        while(conversion.status==XRCpuImage.AsyncConversionStatus.Processing)yield return null;
        if(conversion.status!=XRCpuImage.AsyncConversionStatus.Ready)
        {Warn("CPU-image conversion failed; frame skipped");CancelPending();yield break;}
        if(!focused||paused||Screen.orientation!=orientation||Screen.width!=screen.x||Screen.height!=screen.y)
        {CancelPending();yield break;}
        try
        {
            EnsureTexture(ref rawTexture,dimensions.x,dimensions.y,"YOLO raw CPU image");
            rawTexture.LoadRawTextureData(conversion.GetData<byte>());
            // CPU-only sampling below; Apply/upload is unnecessary.
            ReleaseConversion();
            float scale=(float)maximumImageSide/Mathf.Max(screen.x,screen.y);
            int width=Mathf.Max(1,Mathf.RoundToInt(screen.x*scale)),height=Mathf.Max(1,Mathf.RoundToInt(screen.y*scale));
            EnsureTexture(ref displayTexture,width,height,"YOLO display-oriented CPU image");
            displayTexture.SetPixels32(OrientPixels(rawTexture.GetPixels32(),dimensions,width,height,matrix));
            if(!detector.RunImage(displayTexture))Warn("detector could not run; inspect its model/input warning");
        }
        catch(Exception e){Warn("frame processing failed: "+e.Message);}
        finally
        {
            ReleaseConversion();busy=false;pending=null;
            // Slow devices get a full interval after completion; no queued frame backlog.
            nextInference=Time.unscaledTime+Mathf.Max(.1f,inferenceInterval);
        }
    }
    private static Color32[] OrientPixels(Color32[] raw,Vector2Int source,int width,int height,Matrix4x4 displayMatrix)
    {
        var result=new Color32[width*height];
        for(int y=0;y<height;y++)for(int x=0;x<width;x++)
        {
            float u=(x+.5f)/width,v=(y+.5f)/height;
            // Same row-vector * matrix convention as the ARCore background shader.
            // The matrix already contains the CPU-image y flip, rotation, mirror and viewport crop.
            float rawU=u*displayMatrix.m00+v*displayMatrix.m10+displayMatrix.m20;
            float rawV=u*displayMatrix.m01+v*displayMatrix.m11+displayMatrix.m21;
            int sx=Mathf.Clamp(Mathf.FloorToInt(rawU*source.x),0,source.x-1);
            int sy=Mathf.Clamp(Mathf.FloorToInt(rawV*source.y),0,source.y-1);
            result[y*width+x]=raw[sy*source.x+sx];
        }
        return result;
    }
    private static void EnsureTexture(ref Texture2D texture,int width,int height,string label)
    {
        if(texture!=null&&texture.width==width&&texture.height==height)return;
        if(texture!=null)Destroy(texture);
        texture=new Texture2D(width,height,TextureFormat.RGBA32,false){name=label};
    }
    private void Update()
    {if(focused&&!paused&&Time.unscaledTime-lastFrame>5f)Warn("no AR camera frames; Editor has no live ARCore camera, or the device camera is unavailable");}
    private void Warn(string message)
    {if(Time.unscaledTime<nextWarning)return;nextWarning=Time.unscaledTime+5f;Debug.LogWarning("Live YOLO: "+message,this);}
    private void ReleaseConversion(){if(!ownsConversion)return;conversion.Dispose();ownsConversion=false;}
    private void CancelPending(){if(pending!=null)StopCoroutine(pending);pending=null;ReleaseConversion();busy=false;}
    private void OnDisable()
    {
        if(cameraManager!=null)cameraManager.frameReceived-=OnFrame;
        CancelPending();if(rawTexture!=null)Destroy(rawTexture);if(displayTexture!=null)Destroy(displayTexture);rawTexture=displayTexture=null;
        if(detector!=null)detector.ReleaseRuntimeResources();
    }
    private void OnApplicationFocus(bool value){focused=value;if(!value)CancelPending();}
    private void OnApplicationPause(bool value){paused=value;if(value)CancelPending();}
}

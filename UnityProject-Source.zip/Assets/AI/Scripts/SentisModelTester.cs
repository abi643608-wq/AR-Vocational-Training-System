using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.InferenceEngine;

/// <summary>One image inference, isolated from the AR camera and training controllers.</summary>
[DisallowMultipleComponent]
public sealed class SentisModelTester : MonoBehaviour
{
    [SerializeField] private ModelAsset modelAsset;
    [SerializeField] private Texture2D testTexture;
    [SerializeField] private bool runOnStart;
    [Tooltip("Match the model's documented image layout; most ONNX vision models use NCHW.")]
    [SerializeField] private TensorLayout inputLayout = TensorLayout.NCHW;
    [Tooltip("Only required for dynamic input shapes. Set the model's intended width and height.")]
    [SerializeField] private Vector2Int dynamicInputSize;
    [SerializeField, Range(1,4)] private int dynamicInputChannels = 3;
    [SerializeField, Range(0,1)] private float confidenceThreshold = .4f;
    [SerializeField, Range(0,1)] private float nmsIouThreshold = .45f;
    [SerializeField, Min(1)] private int maximumDetections = 100;
    public bool IsBusy { get; private set; }
    private Worker cachedWorker;
    private Model cachedModel;
    private ModelAsset loadedAsset;
    private void OnDisable() => ReleaseWorker();
    private void OnDestroy() => ReleaseWorker();
    public void ReleaseRuntimeResources() { if(!IsBusy)ReleaseWorker(); }
    private void ReleaseWorker() { cachedWorker?.Dispose(); cachedWorker=null; cachedModel=null; loadedAsset=null; }

    private const int InputSize = 640;
    private static readonly string[] CocoLabels = {
        "person","bicycle","car","motorcycle","airplane","bus","train","truck","boat","traffic light",
        "fire hydrant","stop sign","parking meter","bench","bird","cat","dog","horse","sheep","cow",
        "elephant","bear","zebra","giraffe","backpack","umbrella","handbag","tie","suitcase","frisbee",
        "skis","snowboard","sports ball","kite","baseball bat","baseball glove","skateboard","surfboard","tennis racket","bottle",
        "wine glass","cup","fork","knife","spoon","bowl","banana","apple","sandwich","orange",
        "broccoli","carrot","hot dog","pizza","donut","cake","chair","couch","potted plant","bed",
        "dining table","toilet","tv","laptop","mouse","remote","keyboard","cell phone","microwave","oven",
        "toaster","sink","refrigerator","book","clock","vase","scissors","teddy bear","hair drier","toothbrush"
    };
    private struct Detection { public int classId; public float confidence; public Rect box; }
    private struct Letterbox { public int left, top, width, height; }

    private void Start() { if (runOnStart) RunTest(); }

    public void RunTest() => RunImage(testTexture, true);

    public bool RunImage(Texture2D image, bool verbose = false)
    {
        if (IsBusy) return false;
        if (gameObject.scene.name != "ARTraining_AI_Test")
        {
            Debug.LogWarning("Sentis test is restricted to ARTraining_AI_Test.", this);
            return false;
        }
        if (modelAsset == null)
        {
            Debug.LogWarning("Sentis: no Model Asset assigned. Assign an imported AI model before running the test.", this);
            return false;
        }
        if (image == null || !image.isReadable)
        {
            Debug.LogWarning("YOLO: assign a Test Texture with Read/Write enabled in its Texture Import Settings.", this);
            return false;
        }

        try
        {
            IsBusy=true;
            if(cachedWorker==null || loadedAsset!=modelAsset)
            {
                ReleaseWorker();cachedModel=ModelLoader.Load(modelAsset);
                cachedWorker=new Worker(cachedModel,BackendType.CPU);loadedAsset=modelAsset;
                Debug.Log($"Sentis: worker ready ({modelAsset.name}, CPU).",this);
            }
            var model=cachedModel;
            if(verbose)Debug.Log($"Sentis: model loaded successfully ({modelAsset.name}).", this);
            if(verbose)foreach (var input in model.inputs)
                Debug.Log($"Sentis input: {input.name}, shape {input.shape}, type {input.dataType}.", this);
            if(verbose)foreach (var output in model.outputs)
                Debug.Log($"Sentis declared output: {output.name}; shape available after inference.", this);
            if (model.inputs.Count != 1 || model.inputs[0].dataType != DataType.Float)
            {
                Debug.LogWarning("Sentis tester supports one float image input only. This model requires a model-specific input adapter.", this);
                return false;
            }
            var declared = model.inputs[0].shape;
            TensorShape shape;
            if (declared.IsStatic()) shape = declared.ToTensorShape();
            else
            {
                if (dynamicInputSize.x <= 0 || dynamicInputSize.y <= 0)
                {
                    Debug.LogWarning("Sentis: dynamic input shape. Set Dynamic Input Size from the model documentation before testing.", this);
                    return false;
                }
                shape = inputLayout == TensorLayout.NCHW
                    ? new TensorShape(1, dynamicInputChannels, dynamicInputSize.y, dynamicInputSize.x)
                    : new TensorShape(1, dynamicInputSize.y, dynamicInputSize.x, dynamicInputChannels);
            }
            int channelAxis = inputLayout == TensorLayout.NCHW ? 1 : 3;
            if (shape.rank != 4 || shape[0] != 1 || shape[channelAxis] < 1 || shape[channelAxis] > 4)
            {
                Debug.LogWarning("Sentis: expected a batch-one, rank-four image tensor with 1–4 channels. Check Input Layout and the model shape.", this);
                return false;
            }
            if (inputLayout != TensorLayout.NCHW || shape != new TensorShape(1,3,InputSize,InputSize))
                throw new InvalidOperationException("This YOLO11n decoder requires NCHW images (1,3,640,640).");

            // CPU works without requiring a change to the project's OpenGLES3 settings.
            var worker=cachedWorker;
            using var tensor = CreateImageInput(image, out var letterbox);
            if(verbose)Debug.Log($"YOLO: {image.name} {image.width}x{image.height} → 640x640 letterbox, RGB / 255, NCHW, top-left origin.", this);

            worker.Schedule(tensor);
            if (model.outputs.Count == 0) throw new InvalidOperationException("Model has no declared outputs.");
            foreach (var output in model.outputs)
            {
                var borrowed = worker.PeekOutput(output.name);
                if (borrowed == null) throw new InvalidOperationException($"Output '{output.name}' unavailable.");
                // Readback waits for execution, so 'completed' means more than merely scheduled.
                using var readback = borrowed.ReadbackAndClone();
                if(verbose)Debug.Log($"Sentis output: {output.name}, shape {readback.shape}, type {readback.dataType}.", this);
                if (output.name == "output0")
                {
                    if (readback is not Tensor<float> values) throw new InvalidOperationException("Expected float output0.");
                    LogDetections(values, letterbox, image, verbose);
                }
                // PeekOutput belongs to the worker; only our readback copy is disposed here.
            }
            if(verbose)Debug.Log("Sentis: inference completed successfully (CPU backend).", this);
            return true;
        }
        catch (Exception exception)
        {
            ReleaseWorker();
            Debug.LogError($"Sentis: inference test failed. {exception.GetType().Name}: {exception.Message}", this);
        }
        finally { IsBusy=false; }
        return false;
    }

    private static Tensor<float> CreateImageInput(Texture2D image, out Letterbox letterbox)
    {
        float gain = Mathf.Min((float)InputSize/image.width, (float)InputSize/image.height);
        letterbox = new Letterbox { width=Mathf.RoundToInt(image.width*gain), height=Mathf.RoundToInt(image.height*gain) };
        letterbox.left=(InputSize-letterbox.width)/2; letterbox.top=(InputSize-letterbox.height)/2;
        int plane=InputSize*InputSize;
        var data=new float[plane*3];
        for(int i=0;i<data.Length;i++)data[i]=114f/255f;
        // GetPixels32 supplies stored RGB bytes, avoiding shader color-space conversion.
        var pixels=image.GetPixels32();
        for(int y=0;y<letterbox.height;y++)for(int x=0;x<letterbox.width;x++)
        {
            float sx=(x+.5f)*image.width/letterbox.width-.5f;
            float sy=(y+.5f)*image.height/letterbox.height-.5f;
            int x0=Mathf.FloorToInt(sx), y0=Mathf.FloorToInt(sy);
            float tx=sx-x0,ty=sy-y0;
            int xa=Mathf.Clamp(x0,0,image.width-1),xb=Mathf.Clamp(x0+1,0,image.width-1);
            // Unity pixel storage starts at the bottom; YOLO's image coordinates start at the top.
            int ya=image.height-1-Mathf.Clamp(y0,0,image.height-1),yb=image.height-1-Mathf.Clamp(y0+1,0,image.height-1);
            Color a=(Color)pixels[ya*image.width+xa],b=(Color)pixels[ya*image.width+xb];
            Color c=(Color)pixels[yb*image.width+xa],d=(Color)pixels[yb*image.width+xb];
            Color rgb=Color.LerpUnclamped(Color.LerpUnclamped(a,b,tx),Color.LerpUnclamped(c,d,tx),ty);
            int index=(y+letterbox.top)*InputSize+x+letterbox.left;
            data[index]=rgb.r;data[plane+index]=rgb.g;data[2*plane+index]=rgb.b;
        }
        return new Tensor<float>(new TensorShape(1,3,InputSize,InputSize),data);
    }

    private void LogDetections(Tensor<float> output, Letterbox letterbox, Texture2D image, bool verbose)
    {
        if(output.shape != new TensorShape(1,84,8400))
            throw new InvalidOperationException($"Unsupported YOLO output {output.shape}; expected (1,84,8400).");
        var candidates=new List<Detection>();
        for(int i=0;i<8400;i++)
        {
            int cls=0;float score=output[0,4,i];
            for(int k=1;k<80;k++)if(output[0,4+k,i]>score){score=output[0,4+k,i];cls=k;}
            // Four xywh channels followed by 80 already-activated class probabilities: no objectness channel.
            if(!float.IsFinite(score)||score<confidenceThreshold)continue;
            float cx=output[0,0,i],cy=output[0,1,i],w=output[0,2,i],h=output[0,3,i];
            if(!float.IsFinite(cx)||!float.IsFinite(cy)||!float.IsFinite(w)||!float.IsFinite(h)||w<=0||h<=0)continue;
            candidates.Add(new Detection{classId=cls,confidence=score,box=new Rect(cx-w/2,cy-h/2,w,h)});
        }
        var kept=Suppress(candidates,nmsIouThreshold,maximumDetections);
        if(verbose)Debug.Log($"YOLO: confidence ≥ {confidenceThreshold:F2}; NMS IoU {nmsIouThreshold:F2}; {candidates.Count} candidates → {kept.Count} detections. Boxes: original-image pixels, top-left origin, xyxy.",this);
        foreach(var hit in kept)
        {
            float x1=Mathf.Clamp((hit.box.xMin-letterbox.left)*image.width/letterbox.width,0,image.width);
            float x2=Mathf.Clamp((hit.box.xMax-letterbox.left)*image.width/letterbox.width,0,image.width);
            float y1=Mathf.Clamp((hit.box.yMin-letterbox.top)*image.height/letterbox.height,0,image.height);
            float y2=Mathf.Clamp((hit.box.yMax-letterbox.top)*image.height/letterbox.height,0,image.height);
            if(verbose)Debug.Log($"Detected: {CocoLabels[hit.classId]} | confidence {hit.confidence:F3} | box xyxy ({x1:F1}, {y1:F1}, {x2:F1}, {y2:F1})",this);
            else Debug.Log($"Detected: {CocoLabels[hit.classId]} | {hit.confidence:F2}",this);
        }
        if(verbose&&kept.Count==0)Debug.Log("YOLO: no objects above the confidence threshold.",this);
    }

    private static List<Detection> Suppress(List<Detection> candidates,float threshold,int limit)
    {
        candidates.Sort((a,b)=>b.confidence.CompareTo(a.confidence));
        var kept=new List<Detection>();
        foreach(var candidate in candidates)
        {
            bool duplicate=false;
            foreach(var accepted in kept)
            {
                if(accepted.classId!=candidate.classId)continue;
                float intersection=Mathf.Max(0,Mathf.Min(accepted.box.xMax,candidate.box.xMax)-Mathf.Max(accepted.box.xMin,candidate.box.xMin))
                    *Mathf.Max(0,Mathf.Min(accepted.box.yMax,candidate.box.yMax)-Mathf.Max(accepted.box.yMin,candidate.box.yMin));
                float union=accepted.box.width*accepted.box.height+candidate.box.width*candidate.box.height-intersection;
                if(union>0&&intersection/union>threshold){duplicate=true;break;}
            }
            if(duplicate)continue;
            kept.Add(candidate);if(kept.Count>=Mathf.Max(1,limit))break;
        }
        return kept;
    }
}

#if UNITY_EDITOR
[UnityEditor.CustomEditor(typeof(SentisModelTester))]
public sealed class SentisModelTesterInspector : UnityEditor.Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        using (new UnityEditor.EditorGUI.DisabledScope(!UnityEditor.EditorApplication.isPlaying))
            if (GUILayout.Button("Run Test")) ((SentisModelTester)target).RunTest();
        UnityEditor.EditorGUILayout.HelpBox("Open ARTraining_AI_Test, assign a model, then enter Play mode and click Run Test (or enable Run On Start).", UnityEditor.MessageType.Info);
    }
}
#endif

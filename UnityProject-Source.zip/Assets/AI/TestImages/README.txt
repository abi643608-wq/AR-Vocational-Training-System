YOLO11n Console Test

Sample photograph: bus.jpg, from the Ultralytics project:
https://raw.githubusercontent.com/ultralytics/ultralytics/main/ultralytics/assets/bus.jpg

Open ARTraining_AI_Test and select Sentis Model Test. Assign a Texture2D to Test Texture. Enable Read/Write in the image importer; use NPOT None and uncompressed RGB/RGBA for an accurate original-image test. Run On Start is enabled; alternatively use Run Test in Play mode.

The tester creates a 640x640 RGB / 255 NCHW tensor using aspect-preserving bilinear resize, centered padding at 114/255, and top-left row order. It reads output0 as four xywh channels followed by 80 COCO class probabilities (no objectness channel), chooses the highest class score per candidate, and performs class-aware NMS. Default confidence is 0.40 and NMS IoU is 0.45. Console boxes are xyxy original-image pixels with top-left origin. No live camera input or visual boxes are used.

COCO labels: https://raw.githubusercontent.com/ultralytics/ultralytics/main/ultralytics/cfg/datasets/coco.yaml
Decoder/NMS reference: https://docs.ultralytics.com/reference/utils/nms/
Letterbox reference: https://docs.ultralytics.com/reference/data/augment/

Verified in the Unity Editor: 40 candidates -> 5 detections, bus 0.940 and four people at 0.902, 0.849, 0.838, 0.403. Focused NMS checks preserved separate objects/different classes and removed same-class overlap. Android execution has not been tested.

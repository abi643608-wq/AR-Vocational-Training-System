using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

/// <summary>Mobile mesh generator for a single stored-pressure dry-powder training design.</summary>
public static class SIHRealisticExtinguisherModel
{
    private const string DefaultPath = "Assets/Prefabs/Equipment/SIHExtinguisher.prefab";
    private const string MeshFolder = "Assets/Prefabs/Equipment/Generated";
    private const string MaterialFolder = "Assets/Materials/SIH_Equipment";
    private static string backup;
    private static readonly HashSet<string> backedUp = new HashSet<string>();

    [MenuItem("Tools/SIH/Rebuild Detailed Extinguisher")]
    public static void Rebuild() => Build(DefaultPath);

    public static SIHExtinguisher Build(string path)
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Stop Play mode first.");
        backup = "Backups/DetailedExtinguisher_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        backedUp.Clear();
        Directory.CreateDirectory(backup);
        Backup(path);
        Directory.CreateDirectory(MeshFolder);
        Directory.CreateDirectory(MaterialFolder);
        AssetDatabase.Refresh();
        var paint = Material("SIH_Red", new Color(.57f,.012f,.016f), .18f, .36f);
        var rubber = Material("SIH_Dark", new Color(.022f,.026f,.031f), 0, .19f);
        var steel = Material("SIH_Silver", new Color(.58f,.62f,.66f), .83f, .43f);
        var grip = Material("SIH_Handle", new Color(.065f,.073f,.082f), .55f, .3f);
        var brass = Material("SIH_Valve", new Color(.46f,.32f,.12f), .75f, .36f);
        var label = Material("SIH_Label", new Color(.93f,.93f,.89f), 0, .22f);
        label.SetTexture("_BaseMap", LabelTexture());
        var gauge = Material("SIH_Gauge", Color.white, 0, .26f);
        gauge.SetTexture("_BaseMap", GaugeTexture());
        var marker = Material("SIH_Selection", new Color(.85f,.63f,.10f), .1f, .24f);
        marker.EnableKeyword("_EMISSION"); marker.SetColor("_EmissionColor", new Color(.12f,.08f,.005f));
        var old = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        var root = old != null ? PrefabUtility.LoadPrefabContents(path) : new GameObject("SIHExtinguisher");
        try
        {
            // Preserve the root and its script/collider fileIDs; replace only model children.
            while (root.transform.childCount > 0) UnityEngine.Object.DestroyImmediate(root.transform.GetChild(0).gameObject);
            Part(root, "Painted Vessel", Lathe(new[] {
                P(0,.009f),P(.040f,.009f),P(.056f,.013f),P(.068f,.020f),P(.078f,.032f),P(.083f,.047f),
                P(.084f,.065f),P(.084f,.370f),P(.0838f,.387f),P(.081f,.401f),P(.075f,.416f),
                P(.065f,.430f),P(.050f,.442f),P(.035f,.450f),P(.023f,.454f),P(.022f,.468f),P(0,.468f)
            },64), paint);
            Part(root, "Contact Foot", Lathe(new[] { P(.054f,0),P(.068f,0),P(.072f,.003f),P(.074f,.010f),
                P(.073f,.019f),P(.069f,.024f),P(.064f,.021f),P(.061f,.006f),P(.054f,0) },48), rubber);
            Part(root, "Neck Collar", Lathe(new[] {P(.021f,.454f),P(.026f,.457f),P(.026f,.464f),P(.023f,.468f),P(.021f,.468f)},40), steel);
            Part(root, "Valve Block", Lathe(new[] {P(0,.467f),P(.021f,.467f),P(.023f,.471f),P(.023f,.493f),P(.018f,.500f),P(0,.500f)},32), brass);

            // Elliptical swept metal profiles: no cube handles and a clear squeeze gap.
            var fixedHandle = Bezier(new Vector3(-.029f,.488f,0),new Vector3(-.031f,.520f,0),new Vector3(.025f,.522f,0),new Vector3(.115f,.516f,0),24);
            Part(root,"Carry Handle",Tube(fixedHandle,.007f,.018f,10),grip);
            var lever = Bezier(new Vector3(-.025f,.500f,0),new Vector3(-.038f,.568f,0),new Vector3(.060f,.554f,0),new Vector3(.123f,.547f,0),28);
            Part(root,"Squeeze Lever",Tube(lever,.006f,.016f,10),paint);
            Part(root,"Pivot Axle",Tube(new[] {new Vector3(-.025f,.503f,-.023f),new Vector3(-.025f,.503f,.023f)},.005f,.005f,16),steel);
            var pin = new GameObject("Safety Pin"); pin.transform.SetParent(root.transform,false);
            Part(pin,"Pin Shaft",Tube(new[] {new Vector3(.002f,.512f,.021f),new Vector3(.002f,.512f,-.061f)},.0021f,.0021f,10),steel);
            var pull = Part(root,"Pull Ring",Circle(new Vector3(-.016f,.512f,-.061f),.018f,.0018f,false,40,8),steel);
            // Pin and ring remain separate named transforms for a later pull-pin step.

            var hosePoints = Bezier(new Vector3(.018f,.485f,.016f),new Vector3(.20f,.56f,.020f),
                new Vector3(.175f,.29f,.016f),new Vector3(.136f,.190f,.014f),44);
            Part(root,"Rubber Hose",Tube(hosePoints,.008f,.008f,12),rubber);
            Part(root,"Hose Coupling",Tube(new[] {hosePoints[0],hosePoints[3]},.011f,.011f,16),brass);
            Vector3 tip = new Vector3(.121f,.126f,.013f);
            Part(root,"Discharge Nozzle",Tube(new[] {hosePoints[hosePoints.Length-1],Vector3.Lerp(hosePoints[hosePoints.Length-1],tip,.18f),tip},.014f,.014f,20),rubber);
            Part(root,"Nozzle Rim",Tube(new[] {tip,tip+new Vector3(-.0015f,-.006f,0)},.015f,.015f,20),steel);
            // A dark recessed aperture, without a CO2 horn or foam applicator.
            Part(root,"Nozzle Aperture",Tube(new[] {tip+new Vector3(-.0014f,-.0061f,0),tip+new Vector3(-.0015f,-.0062f,0)},.010f,.010f,16),rubber);

            var bezel = Part(root,"Gauge Bezel",Lathe(new[] {P(0,0),P(.018f,0),P(.021f,.003f),P(.021f,.010f),P(.0185f,.013f),P(0,.013f)},40),steel);
            bezel.transform.localPosition = new Vector3(0,.492f,-.026f);
            bezel.transform.localRotation = Quaternion.Euler(-90,0,0);
            var face = Part(root,"Pressure Gauge",Disc(.0175f,40),gauge);
            face.transform.localPosition = new Vector3(0,.492f,-.0395f);
            face.transform.localRotation = Quaternion.Euler(-90,0,0);
            Part(root,"Conforming Label",LabelMesh(.0846f,.155f,.355f,1.04f,40),label);
            var highlight = Part(root,"Selection Highlight",Circle(new Vector3(0,.003f,0),.112f,.0015f,true,64,6),marker);
            highlight.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;
            highlight.SetActive(false);
            var collider = root.GetComponent<BoxCollider>();
            if (collider == null) collider = root.AddComponent<BoxCollider>();
            // Keep the existing collider component; fit its shape to the new silhouette.
            collider.center = new Vector3(.038f,.282f,0); collider.size = new Vector3(.272f,.564f,.182f);
            var component = root.GetComponent<SIHExtinguisher>();
            if (component == null) component = root.AddComponent<SIHExtinguisher>();
            component.Configure(collider,highlight);
            var pinInteraction = root.GetComponent<SIHSafetyPin>();
            if (pinInteraction == null) pinInteraction = root.AddComponent<SIHSafetyPin>();
            pinInteraction.Configure(pin.transform,pull.transform);
            var saved = PrefabUtility.SaveAsPrefabAsset(root,path);
            AssetDatabase.SaveAssets();
            Debug.Log("Detailed dry-powder training model rebuilt. Backup: " + backup);
            return saved.GetComponent<SIHExtinguisher>();
        }
        finally { if (old != null) PrefabUtility.UnloadPrefabContents(root); else UnityEngine.Object.DestroyImmediate(root); }
    }

    private static void Backup(string path)
    {
        if (!File.Exists(path) || !backedUp.Add(path)) return;
        string destination = Path.Combine(backup,path);
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        File.Copy(path,destination);
        if (File.Exists(path+".meta")) File.Copy(path+".meta",destination+".meta");
    }
    private static Material Material(string name, Color color, float metallic, float smoothness)
    {
        string path = MaterialFolder+"/"+name+".mat";
        Backup(path);
        var m = AssetDatabase.LoadAssetAtPath<Material>(path);
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) throw new InvalidOperationException("URP Lit unavailable.");
        if (m == null) { m = new Material(shader); AssetDatabase.CreateAsset(m,path); }
        m.shader=shader; m.SetColor("_BaseColor",color); m.SetFloat("_Metallic",metallic);
        // Avoid noisy environment specular while retaining URP Lit direct highlights.
        m.SetFloat("_EnvironmentReflections",0); m.EnableKeyword("_ENVIRONMENTREFLECTIONS_OFF");
        m.SetFloat("_Smoothness",smoothness); m.SetFloat("_Surface",0); m.SetFloat("_Cull",2);
        EditorUtility.SetDirty(m); return m;
    }
    private static GameObject Part(GameObject root, string name, Mesh mesh, Material material)
    {
        string path = MeshFolder+"/"+name.Replace(" ","_")+".asset";
        Backup(path);
        var saved=AssetDatabase.LoadAssetAtPath<Mesh>(path);
        mesh.name=name;
        if(saved==null) { AssetDatabase.CreateAsset(mesh,path); saved=mesh; }
        else { EditorUtility.CopySerialized(mesh,saved); UnityEngine.Object.DestroyImmediate(mesh); EditorUtility.SetDirty(saved); }
        var go=new GameObject(name,typeof(MeshFilter),typeof(MeshRenderer));
        go.transform.SetParent(root.transform,false); go.GetComponent<MeshFilter>().sharedMesh=saved;
        var r=go.GetComponent<MeshRenderer>(); r.sharedMaterial=material;
        r.shadowCastingMode=ShadowCastingMode.On; r.receiveShadows=true;
        return go;
    }
    private static Vector2 P(float radius,float height)=>new Vector2(radius,height);
    private static Mesh Mesh(List<Vector3> v,List<Vector3> n,List<Vector2> uv,List<int> triangles)
    {
        var m=new Mesh(); m.SetVertices(v); m.SetNormals(n); m.SetUVs(0,uv); m.SetTriangles(triangles,0);
        m.RecalculateBounds(); m.RecalculateTangents(); return m;
    }
    private static Mesh Lathe(Vector2[] profile,int sides)
    {
        var v=new List<Vector3>(); var n=new List<Vector3>(); var uv=new List<Vector2>(); var tr=new List<int>();
        for(int j=0;j<profile.Length;j++)
        {
            Vector2 tangent=profile[Mathf.Min(j+1,profile.Length-1)]-profile[Mathf.Max(0,j-1)];
            for(int i=0;i<=sides;i++)
            {
                float a=i*2*Mathf.PI/sides; v.Add(new Vector3(profile[j].x*Mathf.Cos(a),profile[j].y,profile[j].x*Mathf.Sin(a)));
                n.Add(new Vector3(tangent.y*Mathf.Cos(a),-tangent.x,tangent.y*Mathf.Sin(a)).normalized);
                uv.Add(new Vector2((float)i/sides,(float)j/(profile.Length-1)));
                if(j<profile.Length-1 && i<sides) { int k=j*(sides+1)+i; tr.AddRange(new[]{k,k+sides+1,k+1,k+1,k+sides+1,k+sides+2}); }
            }
        }
        return Mesh(v,n,uv,tr);
    }
    private static Vector3[] Bezier(Vector3 a,Vector3 b,Vector3 c,Vector3 d,int steps)
    {
        var p=new Vector3[steps+1];
        for(int i=0;i<=steps;i++) { float t=(float)i/steps,s=1-t; p[i]=s*s*s*a+3*s*s*t*b+3*s*t*t*c+t*t*t*d; }
        return p;
    }
    private static Mesh Tube(Vector3[] path,float radius,float depth,int sides)
    {
        var v=new List<Vector3>(); var n=new List<Vector3>(); var uv=new List<Vector2>(); var tr=new List<int>();
        for(int j=0;j<path.Length;j++)
        {
            var tangent=(path[Mathf.Min(j+1,path.Length-1)]-path[Mathf.Max(0,j-1)]).normalized;
            var reference=Mathf.Abs(Vector3.Dot(tangent,Vector3.forward))>.95f?Vector3.up:Vector3.forward;
            var u=Vector3.Cross(tangent,reference).normalized; var w=Vector3.Cross(tangent,u).normalized;
            for(int i=0;i<=sides;i++)
            {
                float a=i*2*Mathf.PI/sides; var offset=u*Mathf.Cos(a)*radius+w*Mathf.Sin(a)*depth;
                v.Add(path[j]+offset); n.Add((u*Mathf.Cos(a)/radius+w*Mathf.Sin(a)/depth).normalized); uv.Add(new Vector2((float)i/sides,(float)j/(path.Length-1)));
                if(j<path.Length-1 && i<sides) {int k=j*(sides+1)+i;tr.AddRange(new[]{k,k+1,k+sides+1,k+1,k+sides+2,k+sides+1});}
            }
        }
        // End caps have separate normals so rubber and metal ends stay clean.
        for(int end=0;end<2;end++)
        {
            int j=end==0?0:path.Length-1, center=v.Count;
            Vector3 normal=end==0?(path[0]-path[1]).normalized:(path[j]-path[j-1]).normalized;
            v.Add(path[j]);n.Add(normal);uv.Add(new Vector2(.5f,.5f));
            for(int i=0;i<=sides;i++) {v.Add(v[j*(sides+1)+i]);n.Add(normal);uv.Add(Vector2.zero);}
            for(int i=0;i<sides;i++) tr.AddRange(end==0?new[]{center,center+i+2,center+i+1}:new[]{center,center+i+1,center+i+2});
        }
        return Mesh(v,n,uv,tr);
    }
    private static Mesh Circle(Vector3 center,float radius,float thickness,bool horizontal,int steps,int sides)
    {
        // Closed torus with analytic normals; avoids billboard orientation and cap seams.
        var v=new List<Vector3>();var n=new List<Vector3>();var uv=new List<Vector2>();var tr=new List<int>();
        for(int j=0;j<=steps;j++) for(int i=0;i<=sides;i++)
        {
            float a=2*Mathf.PI*j/steps,b=2*Mathf.PI*i/sides;
            Vector3 radial=horizontal?new Vector3(Mathf.Cos(a),0,Mathf.Sin(a)):new Vector3(Mathf.Cos(a),Mathf.Sin(a),0);
            Vector3 axis=horizontal?Vector3.up:Vector3.forward;
            Vector3 normal=radial*Mathf.Cos(b)+axis*Mathf.Sin(b);
            v.Add(center+radial*radius+normal*thickness);n.Add(normal);uv.Add(new Vector2((float)j/steps,(float)i/sides));
            if(j<steps&&i<sides) {int k=j*(sides+1)+i;tr.AddRange(horizontal?new[]{k,k+1,k+sides+1,k+1,k+sides+2,k+sides+1}:new[]{k,k+sides+1,k+1,k+1,k+sides+1,k+sides+2});}
        }
        return Mesh(v,n,uv,tr);
    }
    private static Mesh LabelMesh(float radius,float bottom,float top,float halfAngle,int steps)
    {
        var v=new List<Vector3>();var n=new List<Vector3>();var uv=new List<Vector2>();var tr=new List<int>();
        for(int j=0;j<2;j++) for(int i=0;i<=steps;i++)
        {
            float a=Mathf.Lerp(-halfAngle,halfAngle,(float)i/steps); Vector3 normal=new Vector3(Mathf.Sin(a),0,-Mathf.Cos(a));
            v.Add(normal*radius+Vector3.up*(j==0?bottom:top));n.Add(normal);uv.Add(new Vector2((float)i/steps,j));
            if(j==0&&i<steps)tr.AddRange(new[]{i,i+steps+1,i+1,i+1,i+steps+1,i+steps+2});
        }
        return Mesh(v,n,uv,tr);
    }
    private static Mesh Disc(float radius,int steps)
    {
        var v=new List<Vector3>{Vector3.zero};var n=new List<Vector3>{Vector3.up};var uv=new List<Vector2>{new Vector2(.5f,.5f)};var tr=new List<int>();
        for(int i=0;i<=steps;i++){float a=2*Mathf.PI*i/steps;v.Add(new Vector3(Mathf.Cos(a)*radius,0,Mathf.Sin(a)*radius));n.Add(Vector3.up);uv.Add(new Vector2(.5f+.5f*Mathf.Cos(a),.5f+.5f*Mathf.Sin(a)));if(i<steps)tr.AddRange(new[]{0,i+2,i+1});}
        return Mesh(v,n,uv,tr);
    }

    private static Texture2D SaveTexture(string name,Texture2D texture)
    {
        string path=MaterialFolder+"/"+name+".png";Backup(path);File.WriteAllBytes(path,texture.EncodeToPNG());UnityEngine.Object.DestroyImmediate(texture);
        AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport);
        var importer=(TextureImporter)AssetImporter.GetAtPath(path);
        importer.maxTextureSize=512;importer.mipmapEnabled=true;importer.wrapMode=TextureWrapMode.Clamp;importer.filterMode=FilterMode.Bilinear;
        importer.textureCompression=TextureImporterCompression.Compressed;
        importer.alphaSource=TextureImporterAlphaSource.None;
        importer.SetPlatformTextureSettings(new TextureImporterPlatformSettings {name="Android",overridden=true,maxTextureSize=512,format=TextureImporterFormat.ETC2_RGB4});
        importer.SaveAndReimport();return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
    }
    private static void Box(Texture2D t,int x,int y,int width,int height,Color c)
    {for(int yy=y;yy<y+height;yy++)for(int xx=x;xx<x+width;xx++)if(xx>=0&&yy>=0&&xx<t.width&&yy<t.height)t.SetPixel(xx,yy,c);}
    private static Texture2D LabelTexture()
    {
        var t=new Texture2D(512,512,TextureFormat.RGBA32,false);Box(t,0,0,512,512,new Color(.93f,.93f,.89f));
        var dark=new Color(.04f,.055f,.075f);var blue=new Color(.025f,.17f,.42f);
        Box(t,14,14,484,484,dark);Box(t,18,18,476,476,new Color(.94f,.94f,.90f));
        Box(t,18,369,476,125,blue);Text(t,"DRY",202,449,6,Color.white);Text(t,"POWDER",149,392,6,Color.white);
        Text(t,"SIH",211,311,6,dark);Text(t,"TRAINING MODEL",83,267,4,dark);
        Box(t,42,245,428,3,blue);
        Text(t,"STORED PRESSURE",47,205,4,dark);
        Text(t,"SIMULATION ONLY",77,156,3,dark);
        for(int i=0;i<3;i++){Box(t,51+i*143,75,113,48,dark);Box(t,55+i*143,79,105,40,new Color(.89f,.90f,.86f));Text(t,(i+1).ToString(),99+i*143,87,4,blue);}
        Text(t,"SIH  EQUIPMENT",88,36,3,dark);t.Apply();return SaveTexture("Training_Label",t);
    }
    private static Texture2D GaugeTexture()
    {
        var t=new Texture2D(128,128,TextureFormat.RGBA32,false);Box(t,0,0,128,128,new Color(.89f,.9f,.87f));
        for(int y=0;y<128;y++)for(int x=0;x<128;x++)
        {
            var p=new Vector2(x-64,y-64);float a=Mathf.Atan2(p.y,p.x)*Mathf.Rad2Deg;
            if(p.magnitude>43&&p.magnitude<55&&a>20&&a<160)t.SetPixel(x,y,a>60&&a<120?new Color(.04f,.42f,.14f):new Color(.67f,.035f,.025f));
            if(Mathf.Abs(x-64)<2&&y>60&&y<108)t.SetPixel(x,y,Color.black);
            if(p.magnitude<6)t.SetPixel(x,y,Color.black);
        }
        t.Apply();return SaveTexture("Pressure_Gauge",t);
    }
    // Small bitmap glyph set keeps generated label artwork reproducible without OS fonts.
    private static readonly string[] Glyphs={
        "A:01110100011000111111100011000110001","B:11110100011000111110100011000111110","C:01111100001000010000100001000001111",
        "D:11110100011000110001100011000111110","E:11111100001000011110100001000011111","F:11111100001000011110100001000010000",
        "G:01111100001000010111100011000101111","H:10001100011000111111100011000110001","I:11111001000010000100001000010011111",
        "J:00111000100001000010100101001001100","K:10001100101010011000101001001010001","L:10000100001000010000100001000011111",
        "M:10001110111010110101100011000110001","N:10001110011010110011100011000110001","O:01110100011000110001100011000101110",
        "P:11110100011000111110100001000010000","Q:01110100011000110001101011001001101","R:11110100011000111110101001001010001",
        "S:01111100001000001110000010000111110","T:11111001000010000100001000010000100","U:10001100011000110001100011000101110",
        "V:10001100011000110001100010101000100","W:10001100011000110101101011101110001","X:10001100010101000100010101000110001",
        "Y:10001100010101000100001000010000100","Z:11111000010001000100010001000011111",
        "1:00100011000010000100001000010001110","2:01110100010000100010001000100011111","3:11110000010000101110000010000111110"};
    private static void Text(Texture2D t,string text,int x,int y,int scale,Color color)
    {
        foreach(char c in text)
        {
            string glyph=Array.Find(Glyphs,g=>g[0]==c);
            if(glyph!=null)for(int row=0;row<7;row++)for(int col=0;col<5;col++)if(glyph[2+row*5+col]=='1')Box(t,x+col*scale,y+(6-row)*scale,scale,scale,color);
            x+=6*scale;
        }
    }
}


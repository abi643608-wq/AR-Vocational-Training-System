using TMPro;
using UnityEditor;
using UnityEngine;

public static class SIHSweepFeedbackSetup
{
    public static void Wire(SIHAimSprayController controller)
    {
        var prompts=Object.FindFirstObjectByType<SIHTrainingPrompts>();
        var canvas=prompts.GetComponent<Canvas>();
        var root=canvas.transform.Find("Sweep Feedback");
        if(root==null){root=new GameObject("Sweep Feedback",typeof(RectTransform)).transform;root.SetParent(canvas.transform,false);}
        var rect=(RectTransform)root;rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=rect.offsetMax=Vector2.zero;
        var count=Panel(root,"Pass Progress",new Vector2(.2f,.73f),new Vector2(.8f,.82f),Vector2.zero,"Sweep passes: 0/2",30);
        var left=Panel(root,"Left Endpoint",new Vector2(.5f,.5f),new Vector2(.5f,.5f),new Vector2(74,64),"L",34);
        var right=Panel(root,"Right Endpoint",new Vector2(.5f,.5f),new Vector2(.5f,.5f),new Vector2(74,64),"R",34);
        var debug=Panel(root,"Development Diagnostics",new Vector2(.12f,.60f),new Vector2(.88f,.71f),Vector2.zero,"DEV",23);
        var feedback=root.GetComponent<SIHSweepFeedback>();if(feedback==null)feedback=root.gameObject.AddComponent<SIHSweepFeedback>();
        feedback.Configure(controller,count,left,right,debug);EditorUtility.SetDirty(feedback);
        foreach(Transform child in root)child.gameObject.SetActive(false);
    }
    private static TMP_Text Panel(Transform parent,string name,Vector2 min,Vector2 max,Vector2 size,string text,float fontSize)
    {
        var existing=parent.Find(name);
        var panel=existing!=null?(RectTransform)existing:new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();
        panel.SetParent(parent,false);panel.anchorMin=min;panel.anchorMax=max;panel.pivot=new Vector2(.5f,.5f);panel.sizeDelta=size;panel.anchoredPosition=Vector2.zero;
        var image=panel.GetComponent<UnityEngine.UI.Image>();if(image==null)image=panel.gameObject.AddComponent<UnityEngine.UI.Image>();image.color=new Color(.02f,.035f,.05f,.83f);image.raycastTarget=false;
        var labelTransform=panel.Find("Label");var labelRect=labelTransform!=null?(RectTransform)labelTransform:new GameObject("Label",typeof(RectTransform)).GetComponent<RectTransform>();labelRect.SetParent(panel,false);labelRect.anchorMin=Vector2.zero;labelRect.anchorMax=Vector2.one;labelRect.offsetMin=new Vector2(5,3);labelRect.offsetMax=new Vector2(-5,-3);
        var label=labelRect.GetComponent<TextMeshProUGUI>();if(label==null)label=labelRect.gameObject.AddComponent<TextMeshProUGUI>();label.font=TMP_Settings.defaultFontAsset;label.fontSize=fontSize;label.alignment=TextAlignmentOptions.Center;label.text=text;label.color=Color.white;label.raycastTarget=false;return label;
    }
}


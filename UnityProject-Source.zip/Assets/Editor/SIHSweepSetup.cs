using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class SIHSweepSetup
{
    [MenuItem("Tools/SIH/Setup Sweep Assessment")]
    public static void Setup()
    {
        var scene=SceneManager.GetActiveScene();
        if(EditorApplication.isPlayingOrWillChangePlaymode || scene.path!="Assets/Scenes/ARTraining.unity")throw new InvalidOperationException("Open current ARTraining in Edit mode.");
        var controller=scene.GetRootGameObjects().SelectMany(g=>g.GetComponentsInChildren<SIHAimSprayController>(true)).Single();
        var existing=scene.GetRootGameObjects().SelectMany(g=>g.GetComponentsInChildren<SIHSweepAssessment>(true)).ToArray();
        if(existing.Length>1 || (existing.Length==1&&existing[0].gameObject!=controller.gameObject))throw new InvalidOperationException("Inspect existing sweep assessor before setup: expected it beside the aim controller.");
        string folder="Backups/SweepSetup_"+DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");Directory.CreateDirectory(folder);
        File.Copy(scene.path,folder+"/ARTraining.unity");File.Copy(scene.path+".meta",folder+"/ARTraining.unity.meta");
        if(!EditorSceneManager.SaveScene(scene,folder+"/ARTraining-live.unity",true))throw new IOException("Live scene backup failed.");
        var sweep=controller.GetComponent<SIHSweepAssessment>();if(sweep==null)sweep=controller.gameObject.AddComponent<SIHSweepAssessment>();
        controller.ConfigureSweep(sweep);EditorUtility.SetDirty(controller);EditorUtility.SetDirty(sweep);
        SIHSweepFeedbackSetup.Wire(controller);
        EditorSceneManager.MarkSceneDirty(scene);EditorSceneManager.SaveScene(scene);
        Debug.Log("Sweep assessment wired; backup: "+folder);
    }
}


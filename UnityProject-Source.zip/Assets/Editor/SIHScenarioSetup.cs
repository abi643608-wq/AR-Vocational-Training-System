using System;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class SIHScenarioSetup
{
    [MenuItem("Tools/SIH/Setup Hazard and Equipment Questions")]
    public static void Setup()
    {
        var scene=SceneManager.GetActiveScene();if(EditorApplication.isPlayingOrWillChangePlaymode||scene.path!="Assets/Scenes/ARTraining.unity")throw new InvalidOperationException("Open current ARTraining in Edit mode.");
        var c=UnityEngine.Object.FindObjectsByType<SIHAimSprayController>(FindObjectsSortMode.None).Single();var p=UnityEngine.Object.FindObjectsByType<ARPlacementController>(FindObjectsSortMode.None).Single();var e=c.GetComponent<SIHExtinguisherSelection>();var a=c.GetComponent<SIHAssessmentRecorder>();if(e==null||a==null)throw new InvalidOperationException("Existing equipment/assessment components required.");
        var backup="Backups/ScenarioSetup_"+DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");Directory.CreateDirectory(backup);File.Copy(scene.path,backup+"/ARTraining.unity");File.Copy(scene.path+".meta",backup+"/ARTraining.unity.meta");if(!EditorSceneManager.SaveScene(scene,backup+"/ARTraining-live.unity",true))throw new IOException("Scene backup failed");
        if(!AssetDatabase.IsValidFolder("Assets/Scenarios"))AssetDatabase.CreateFolder("Assets","Scenarios");
        const string path="Assets/Scenarios/OutdoorWood_UK.asset";var s=AssetDatabase.LoadAssetAtPath<SIHScenarioDefinition>(path);
        if(s==null){s=ScriptableObject.CreateInstance<SIHScenarioDefinition>();Defaults(s);AssetDatabase.CreateAsset(s,path);}
        if(!s.Validate(out var reason))throw new InvalidOperationException(reason);
        var all=UnityEngine.Object.FindObjectsByType<SIHScenarioInteraction>(FindObjectsSortMode.None);if(all.Length>1||(all.Length==1&&all[0].gameObject!=c.gameObject))throw new InvalidOperationException("Inspect existing scenario components first");
        var f=c.GetComponent<SIHScenarioInteraction>();if(f==null)f=c.gameObject.AddComponent<SIHScenarioInteraction>();f.Configure(s,p,c,e);c.ConfigureScenario(f);e.ConfigureScenario(f);a.ConfigureScenario(f);
        var canvas=UnityEngine.Object.FindFirstObjectByType<SIHTrainingPrompts>().GetComponent<Canvas>();
        var root=Rect("Scenario Questions",canvas.transform,Vector2.zero,Vector2.one);Background(root,Color.clear);root.SetAsLastSibling();var safe=Rect("Safe Area",root,Vector2.zero,Vector2.one);
        var sheet=Rect("Question Sheet",safe,Vector2.zero,new Vector2(1,.52f));Background(sheet,new Color(.025f,.045f,.055f,1));
        foreach(var name in new[]{"Question Scroll","Feedback Panel","Continue","Restart Exercise","Reconfigure Route"}){var old=safe.Find(name);if(old!=null)old.SetParent(sheet,false);}
        var scrollRoot=Rect("Question Scroll",sheet,new Vector2(.035f,.27f),new Vector2(.965f,.96f));var scroll=Get<UnityEngine.UI.ScrollRect>(scrollRoot);scroll.horizontal=false;scroll.vertical=true;scroll.movementType=UnityEngine.UI.ScrollRect.MovementType.Clamped;
        var viewport=Rect("Viewport",scrollRoot,Vector2.zero,Vector2.one);Background(viewport,new Color(.025f,.045f,.055f));Get<UnityEngine.UI.Mask>(viewport).showMaskGraphic=true;
        var content=Rect("Content",viewport,new Vector2(0,1),Vector2.one);content.pivot=new Vector2(.5f,1);var layout=Get<UnityEngine.UI.VerticalLayoutGroup>(content);layout.spacing=10;layout.padding=new RectOffset(10,10,10,10);layout.childControlWidth=layout.childControlHeight=true;layout.childForceExpandHeight=false;
        Get<UnityEngine.UI.ContentSizeFitter>(content).verticalFit=UnityEngine.UI.ContentSizeFitter.FitMode.PreferredSize;
        var description=Text("Scenario Description",content,27);description.text=s.description;description.alignment=TextAlignmentOptions.TopLeft;
        scroll.viewport=viewport;scroll.content=content;
        var feedback=Text("Feedback",Rect("Feedback Panel",sheet,new Vector2(.05f,.21f),new Vector2(.95f,.265f)),22);feedback.alignment=TextAlignmentOptions.Center;
        var buttonRect=Rect("Continue",sheet,new Vector2(.12f,.11f),new Vector2(.88f,.20f));Background(buttonRect,new Color(.04f,.3f,.23f));var button=Get<UnityEngine.UI.Button>(buttonRect);button.targetGraphic=buttonRect.GetComponent<UnityEngine.UI.Image>();var text=Text("Label",buttonRect,27);text.text="CONTINUE / TRY AGAIN";text.alignment=TextAlignmentOptions.Center;
        for(int i=button.onClick.GetPersistentEventCount()-1;i>=0;i--)UnityEventTools.RemovePersistentListener(button.onClick,i);UnityEventTools.AddPersistentListener(button.onClick,f.ContinueAfterFeedback);
        ActionButton("Restart Exercise","RESTART EXERCISE",sheet,new Vector2(.05f,.015f),new Vector2(.49f,.095f),a.RestartExercise);
        ActionButton("Reconfigure Route","RECONFIGURE ROUTE",sheet,new Vector2(.51f,.015f),new Vector2(.95f,.095f),a.ReconfigureRoute);
        var ui=canvas.GetComponent<SIHScenarioUI>();if(ui==null)ui=canvas.gameObject.AddComponent<SIHScenarioUI>();ui.Configure(f,a,c,root.gameObject,safe,content,description,feedback,button);root.gameObject.SetActive(false);
        foreach(var obj in new UnityEngine.Object[]{f,c,e,a,ui})EditorUtility.SetDirty(obj);AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(scene);EditorSceneManager.SaveScene(scene);Debug.Log("Scenario questions configured; backup "+backup);
    }
    private static void Defaults(SIHScenarioDefinition s)
    {
        s.description="Simulated outdoor yard: a small pile of dry untreated wood is burning. No live electrical equipment, spilled liquid, gas cylinder or cooking oil is involved. Conditions are calm and open, with a clear escape route. Alarm and evacuation arrangements are already in place; this is supervised AR practice, not an instruction to fight a real fire. Identify the material from this description, not the camera image.";
        s.hazardAnswers.Add(new SIHScenarioAnswer{id="a",label="Class A — combustible solids (wood)",feedback="Correct: the described fuel is dry wood, a UK Class A combustible solid."});
        s.hazardAnswers.Add(new SIHScenarioAnswer{id="b",label="Class B — flammable liquids",feedback="The scenario specifies wood and no spilled liquid. Class B describes flammable-liquid fires in this naming system."});
        s.hazardAnswers.Add(new SIHScenarioAnswer{id="f",label="Class F — cooking oils and fats",feedback="No cooking oil or fat is involved. The described fuel is wood, not a Class F cooking-oil fire."});
        s.equipmentChoices.Add(new SIHEquipmentChoice{id="abc6",label="6 kg ABC dry powder — FXP6 training profile",type="ABC powder",rating="43A 233B C",simulationProfile=SIHScenarioDefinition.PowderProfile,accepted=true,feedback="Accepted: this specific ABC powder profile has a documented Class A rating and is suitable for wood in the stated open-air scenario. Powder can impair visibility, affect breathing and permit re-ignition; it is not a general recommendation for enclosed rooms. Class A-rated water/foam may also be suitable, but are not offered in this kit."});
        s.equipmentChoices.Add(new SIHEquipmentChoice{id="bc",label="BC-only dry powder — no Class A rating",type="BC powder",rating="B/C only; no A",simulationProfile="bc",accepted=false,feedback="This offered BC-only unit has no Class A rating for the described wood. Do not assume every dry-powder formulation can extinguish combustible solids; choose the offered A-rated unit."});
        s.equipmentChoices.Add(new SIHEquipmentChoice{id="co2",label="CO2 — Class B-rated unit, no A rating",type="Carbon dioxide",rating="B only; no A",simulationProfile="co2",accepted=false,feedback="This offered CO2 unit has no Class A rating for the described wood. Its liquid/electrical application does not establish suitability for this solid-fuel scenario. No live electrical equipment is involved."});
        s.sources=new[]{"Firechief Global manufacturer product sheet: FXP6, 6 kg ABC powder, 43A 233B C; wood/paper application. https://firechiefglobal.com/wp/wp-content/uploads/2019/09/FMP1_FXP2-12_Product_Sheet_May21-1-1.pdf (reviewed 2026-09-27)","Firechief Global service manual: FXP6 uses ABC40 powder. https://firechiefglobal.com/wp/wp-content/uploads/2022/04/Firechief-Extinguisher-Service-Manual-2022-1.pdf (reviewed 2026-09-27)","UK Government fire-safety risk assessment, offices/shops: UK class definitions, agents and powder limitations. https://www.gov.uk/government/publications/fire-safety-risk-assessment-offices-and-shops/fire-safety-risk-assessment-offices-and-shops-accessible (reviewed 2026-09-27)"};
    }
    private static T Get<T>(Component c)where T:Component{var v=c.GetComponent<T>();return v!=null?v:c.gameObject.AddComponent<T>();}
    private static RectTransform Rect(string name,Transform parent,Vector2 min,Vector2 max){var old=parent.Find(name);var r=old!=null?(RectTransform)old:new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();r.SetParent(parent,false);r.anchorMin=min;r.anchorMax=max;r.offsetMin=r.offsetMax=Vector2.zero;return r;}
    private static void Background(RectTransform r,Color color){var image=Get<UnityEngine.UI.Image>(r);image.color=color;image.raycastTarget=true;}
    private static void ActionButton(string name,string label,Transform parent,Vector2 min,Vector2 max,UnityEngine.Events.UnityAction action){var r=Rect(name,parent,min,max);Background(r,new Color(.04f,.2f,.2f));var b=Get<UnityEngine.UI.Button>(r);b.targetGraphic=r.GetComponent<UnityEngine.UI.Image>();var t=Text("Label",r,23);t.text=label;t.alignment=TextAlignmentOptions.Center;for(int i=b.onClick.GetPersistentEventCount()-1;i>=0;i--)UnityEventTools.RemovePersistentListener(b.onClick,i);UnityEventTools.AddPersistentListener(b.onClick,action);}
    private static TMP_Text Text(string name,Transform parent,float size){var r=Rect(name,parent,Vector2.zero,Vector2.one);var t=Get<TextMeshProUGUI>(r);t.font=TMP_Settings.defaultFontAsset;t.fontSize=size;t.color=Color.white;t.raycastTarget=false;return t;}
}



using UnityEditor;

// Compatibility entry point. All regeneration now uses the detailed mesh builder.
public static class SIHSuppliedExtinguisherModel
{
    [MenuItem("Tools/SIH/Use Supplied Extinguisher Model")]
    public static void Apply() => SIHRealisticExtinguisherModel.Rebuild();
}

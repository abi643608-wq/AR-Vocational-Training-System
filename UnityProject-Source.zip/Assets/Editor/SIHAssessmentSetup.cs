using System;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public static class SIHAssessmentSetup
{
    [MenuItem("Tools/SIH/Setup Assessment Results")]
    public static void Setup()
    {
        var scene=SceneManager.GetActiveScene();
        if(EditorApplication.isPlayingOrWillChangePlaymode||scene.path!="Assets/Scenes/ARTraining.unity")throw new InvalidOperationException("Open current ARTraining in Edit mode.");
        var c=UnityEngine.Object.FindObjectsByType<SIHAimSprayController>(FindObjectsSortMode.None).Single();
        var route=UnityEngine.Object.FindObjectsByType<SIHTrainingRoute>(FindObjectsSortMode.None).Single();
        var equipment=UnityEngine.Object.FindObjectsByType<SIHExtinguisherSelection>(FindObjectsSortMode.None).Single();
        var placement=UnityEngine.Object.FindObjectsByType<ARPlacementController>(FindObjectsSortMode.None).Single();
        var prompts=UnityEngine.Object.FindObjectsByType<SIHTrainingPrompts>(FindObjectsSortMode.None).Single();
        var prior=UnityEngine.Object.FindObjectsByType<SIHAssessmentRecorder>(FindObjectsSortMode.None);
        if(prior.Length>1||(prior.Length==1&&prior[0].gameObject!=c.gameObject))throw new InvalidOperationException("Inspect existing assessment recorders first.");
        var backup="Backups/AssessmentSetup_"+DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");Directory.CreateDirectory(backup);File.Copy(scene.path,backup+"/ARTraining.unity");File.Copy(scene.path+".meta",backup+"/ARTraining.unity.meta");if(!EditorSceneManager.SaveScene(scene,backup+"/ARTraining-live.unity",true))throw new IOException("Scene backup failed.");
        var recorder=c.GetComponent<SIHAssessmentRecorder>();if(recorder==null)recorder=c.gameObject.AddComponent<SIHAssessmentRecorder>();recorder.Configure(c,equipment,placement,route,c.Sweep);
        var canvas=prompts.GetComponent<Canvas>();if(canvas.GetComponent<UnityEngine.UI.GraphicRaycaster>()==null)throw new InvalidOperationException("Existing Canvas needs a GraphicRaycaster.");
        var root=Rect("Assessment Results",canvas.transform,Vector2.zero,Vector2.one);root.SetAsLastSibling();Background(root,new Color(.025f,.045f,.06f,1));
        var safe=Rect("Safe Area",root,Vector2.zero,Vector2.one);
        var title=Text("Heading",Rect("Header",safe,new Vector2(.05f,.8f),new Vector2(.95f,.97f)),32);title.alignment=TextAlignmentOptions.Center;
        var view=Rect("Scroll View",safe,new Vector2(.05f,.16f),new Vector2(.95f,.78f));var sr=Get<UnityEngine.UI.ScrollRect>(view);sr.horizontal=false;sr.vertical=true;sr.movementType=UnityEngine.UI.ScrollRect.MovementType.Clamped;sr.scrollSensitivity=35;
        var viewport=Rect("Viewport",view,Vector2.zero,Vector2.one);Background(viewport,new Color(.025f,.045f,.06f));var mask=Get<UnityEngine.UI.Mask>(viewport);mask.showMaskGraphic=true;
        var content=Rect("Content",viewport,new Vector2(0,1),Vector2.one);content.pivot=new Vector2(.5f,1);
        var layout=Get<UnityEngine.UI.VerticalLayoutGroup>(content);layout.padding=new RectOffset(12,18,14,14);layout.childControlWidth=true;layout.childControlHeight=true;layout.childForceExpandHeight=false;layout.childForceExpandWidth=true;
        var fitter=Get<UnityEngine.UI.ContentSizeFitter>(content);fitter.horizontalFit=UnityEngine.UI.ContentSizeFitter.FitMode.Unconstrained;fitter.verticalFit=UnityEngine.UI.ContentSizeFitter.FitMode.PreferredSize;
        var body=Text("Details",content,26);body.text="Assessment results will appear here.";body.alignment=TextAlignmentOptions.TopLeft;
        sr.viewport=viewport;sr.content=content;
        Button("Restart Exercise","RESTART EXERCISE",safe,new Vector2(.05f,.035f),new Vector2(.49f,.12f),recorder.RestartExercise);
        Button("Reconfigure Route","RECONFIGURE ROUTE",safe,new Vector2(.51f,.035f),new Vector2(.95f,.12f),recorder.ReconfigureRoute);
        var routeRoot=canvas.transform.Find("Training Route UI");var oldSafe=canvas.transform.Find("Safe Area");if(routeRoot==null||oldSafe==null)throw new InvalidOperationException("Existing route HUD missing.");
        var history=Button("Last Results","LAST RESULTS",routeRoot,new Vector2(.04f,.275f),new Vector2(.45f,.328f),recorder.ShowLastResult);
        var ui=canvas.GetComponent<SIHAssessmentResultsUI>();if(ui==null)ui=canvas.gameObject.AddComponent<SIHAssessmentResultsUI>();ui.Configure(recorder,route,root.gameObject,safe,title,body,sr,history.gameObject,new[]{oldSafe.gameObject,routeRoot.gameObject});
        root.gameObject.SetActive(false);history.gameObject.SetActive(false);EditorUtility.SetDirty(recorder);EditorUtility.SetDirty(ui);AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(scene);EditorSceneManager.SaveScene(scene);Debug.Log("Assessment/results wired. Backup: "+backup);
    }
    private static T Get<T>(Component parent) where T:Component{var component=parent.GetComponent<T>();return component!=null?component:parent.gameObject.AddComponent<T>();}
    private static RectTransform Rect(string name,Transform parent,Vector2 min,Vector2 max){var old=parent.Find(name);var r=old!=null?(RectTransform)old:new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();r.SetParent(parent,false);r.anchorMin=min;r.anchorMax=max;r.offsetMin=r.offsetMax=Vector2.zero;return r;}
    private static void Background(RectTransform r,Color color){var image=Get<UnityEngine.UI.Image>(r);image.color=color;image.raycastTarget=true;}
    private static TMP_Text Text(string name,Transform parent,float size){var r=Rect(name,parent,Vector2.zero,Vector2.one);var t=Get<TextMeshProUGUI>(r);t.font=TMP_Settings.defaultFontAsset;t.fontSize=size;t.color=new Color(.92f,.96f,.98f);t.raycastTarget=false;return t;}
    private static UnityEngine.UI.Button Button(string name,string label,Transform parent,Vector2 min,Vector2 max,UnityAction action){var r=Rect(name,parent,min,max);Background(r,new Color(.045f,.28f,.22f));var text=Text("Label",r,22);text.text=label;text.alignment=TextAlignmentOptions.Center;var b=Get<UnityEngine.UI.Button>(r);b.targetGraphic=r.GetComponent<UnityEngine.UI.Image>();for(int i=b.onClick.GetPersistentEventCount()-1;i>=0;i--)UnityEventTools.RemovePersistentListener(b.onClick,i);UnityEventTools.AddPersistentListener(b.onClick,action);return b;}
}

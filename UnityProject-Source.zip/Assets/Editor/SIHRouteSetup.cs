using System;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.XR.ARFoundation;
using Unity.XR.CoreUtils;

public static class SIHRouteSetup
{
    [MenuItem("Tools/SIH/Setup Training Route")]
    public static void Setup()
    {
        var scene=SceneManager.GetActiveScene();
        if(EditorApplication.isPlayingOrWillChangePlaymode||scene.path!="Assets/Scenes/ARTraining.unity")throw new InvalidOperationException("Open current ARTraining in Edit mode.");
        var exercise=UnityEngine.Object.FindObjectsByType<SIHAimSprayController>(FindObjectsSortMode.None).Single();
        var placement=UnityEngine.Object.FindObjectsByType<ARPlacementController>(FindObjectsSortMode.None).Single();
        var session=UnityEngine.Object.FindObjectsByType<ARSession>(FindObjectsSortMode.None).Single();
        var prompts=UnityEngine.Object.FindObjectsByType<SIHTrainingPrompts>(FindObjectsSortMode.None).Single();
        var existing=UnityEngine.Object.FindObjectsByType<SIHTrainingRoute>(FindObjectsSortMode.None);
        if(existing.Length>1||(existing.Length==1&&existing[0].gameObject!=exercise.gameObject))throw new InvalidOperationException("Inspect existing training route components before setup.");
        string backup="Backups/RouteSetup_"+DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");Directory.CreateDirectory(backup);File.Copy(scene.path,backup+"/ARTraining.unity");File.Copy(scene.path+".meta",backup+"/ARTraining.unity.meta");
        if(!EditorSceneManager.SaveScene(scene,backup+"/ARTraining-live.unity",true))throw new IOException("Live scene backup failed.");
        var arrival=exercise.GetComponent<SIHRouteArrival>();if(arrival==null)arrival=exercise.gameObject.AddComponent<SIHRouteArrival>();
        var route=exercise.GetComponent<SIHTrainingRoute>();if(route==null)route=exercise.gameObject.AddComponent<SIHTrainingRoute>();
        const string matPath="Assets/Materials/SIH_Equipment/SIH_TrainingRoute.mat";
        var material=AssetDatabase.LoadAssetAtPath<Material>(matPath);
        if(material==null){material=new Material(Shader.Find("Universal Render Pipeline/Unlit"));material.SetColor("_BaseColor",new Color(.05f,.8f,.3f));AssetDatabase.CreateAsset(material,matPath);}
        route.Configure(placement,exercise,placement.GetComponent<XROrigin>(),session,arrival,material);exercise.ConfigureRoute(route);placement.ConfigureRoute(route);
        var canvas=prompts.GetComponent<Canvas>();if(canvas.GetComponent<UnityEngine.UI.GraphicRaycaster>()==null)canvas.gameObject.AddComponent<UnityEngine.UI.GraphicRaycaster>();
        var root=Rect("Training Route UI",canvas.transform,Vector2.zero,Vector2.one);
        var statusPanel=Rect("Route Status",root,new Vector2(.05f,.68f),new Vector2(.95f,.82f));Background(statusPanel,new Color(.02f,.055f,.04f,.86f));
        var status=Text("Status",statusPanel,"TRAINING ROUTE",25);
        var indicatorRect=Rect("Direction",root,new Vector2(.17f,.57f),new Vector2(.83f,.63f));var indicator=Text("Text",indicatorRect,"",29);
        var controls=Rect("Setup Controls",root,Vector2.zero,Vector2.one);
        Action<string,string,int,UnityAction> button=(name,label,index,action)=>{int row=index/4,col=index%4;float x=.04f+col*.235f,y=.21f-row*.061f;Button(name,label,controls,new Vector2(x,y),new Vector2(x+.22f,y+.053f),action);};
        button("Place Exit","PLACE EXIT",0,route.ChooseExit);button("Add Waypoint","+ WAYPOINT",1,route.ChooseWaypoint);button("Place Assembly","ASSEMBLY",2,route.ChooseAssembly);button("Review","REVIEW",3,route.Review);
        button("Select Next","SELECT NEXT",4,route.NextSelected);button("Move","MOVE",5,route.MoveSelected);button("Delete","DELETE",6,route.DeleteSelected);button("Earlier","EARLIER",7,route.Earlier);button("Later","LATER",8,route.Later);
        var confirm=Button("Confirm","CONFIRM & START",controls,new Vector2(.275f,.088f),new Vector2(.96f,.141f),()=>route.ConfirmRoute());
        // Use a named wrapper for a persistent Inspector callback.
        confirm.onClick.RemoveAllListeners();for(int i=confirm.onClick.GetPersistentEventCount()-1;i>=0;i--)UnityEventTools.RemovePersistentListener(confirm.onClick,i);
        UnityEventTools.AddPersistentListener(confirm.onClick,route.ConfirmFromUI);
        Button("Restart Exercise","RESTART EXERCISE",root,new Vector2(.04f,.018f),new Vector2(.48f,.074f),route.RestartExercise);
        Button("Reconfigure Route","RECONFIGURE ROUTE",root,new Vector2(.52f,.018f),new Vector2(.96f,.074f),route.ReconfigureRoute);
        var oldReset=canvas.transform.Find("Safe Area/Reset Training");if(oldReset!=null)oldReset.gameObject.SetActive(false);
        var ui=root.GetComponent<SIHRouteUI>();if(ui==null)ui=root.gameObject.AddComponent<SIHRouteUI>();ui.Configure(route,controls.gameObject,statusPanel.gameObject,status,indicator,confirm);
        foreach(var obj in new UnityEngine.Object[]{arrival,route,exercise,placement,ui})EditorUtility.SetDirty(obj);
        AssetDatabase.SaveAssets();EditorSceneManager.MarkSceneDirty(scene);EditorSceneManager.SaveScene(scene);
        Debug.Log("Training route setup complete. Backup: "+backup);
    }
    private static RectTransform Rect(string name,Transform parent,Vector2 min,Vector2 max)
    {var existing=parent.Find(name);var rect=existing!=null?(RectTransform)existing:new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();rect.SetParent(parent,false);rect.anchorMin=min;rect.anchorMax=max;rect.offsetMin=rect.offsetMax=Vector2.zero;return rect;}
    private static UnityEngine.UI.Image Background(RectTransform rect,Color color)
    {var image=rect.GetComponent<UnityEngine.UI.Image>();if(image==null)image=rect.gameObject.AddComponent<UnityEngine.UI.Image>();image.color=color;image.raycastTarget=true;return image;}
    private static TMP_Text Text(string name,Transform parent,string value,float size)
    {var rect=Rect(name,parent,Vector2.zero,Vector2.one);rect.offsetMin=new Vector2(5,2);rect.offsetMax=new Vector2(-5,-2);var text=rect.GetComponent<TextMeshProUGUI>();if(text==null)text=rect.gameObject.AddComponent<TextMeshProUGUI>();text.font=TMP_Settings.defaultFontAsset;text.fontSize=size;text.color=Color.white;text.alignment=TextAlignmentOptions.Center;text.text=value;text.raycastTarget=false;return text;}
    private static UnityEngine.UI.Button Button(string name,string label,Transform parent,Vector2 min,Vector2 max,UnityAction action)
    {var rect=Rect(name,parent,min,max);var image=Background(rect,new Color(.035f,.22f,.17f,.95f));Text("Label",rect,label,23);var button=rect.GetComponent<UnityEngine.UI.Button>();if(button==null)button=rect.gameObject.AddComponent<UnityEngine.UI.Button>();button.targetGraphic=image;for(int i=button.onClick.GetPersistentEventCount()-1;i>=0;i--)UnityEventTools.RemovePersistentListener(button.onClick,i);if(action.Target is UnityEngine.Object)UnityEventTools.AddPersistentListener(button.onClick,action);return button;}
}

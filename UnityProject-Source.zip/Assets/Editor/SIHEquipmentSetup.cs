using System;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.ARFoundation;

/// <summary>Idempotent setup of the current ARTraining scene; never loads an old scene copy.</summary>
public static class SIHEquipmentSetup
{
    private const string Folder = "Assets/Prefabs/Equipment";
    private const string PrefabPath = Folder + "/SIHExtinguisher.prefab";
    private static string backupFolder;

    [MenuItem("Tools/SIH/Setup Extinguisher Selection")]
    public static void Setup()
    {
        var scene = SceneManager.GetActiveScene();
        if (EditorApplication.isPlayingOrWillChangePlaymode || scene.path != "Assets/Scenes/ARTraining.unity")
            throw new InvalidOperationException("Open the current Assets/Scenes/ARTraining.unity in Edit mode first.");
        var placements = InScene<ARPlacementController>(scene);
        if (placements.Length != 1) throw new InvalidOperationException("Expected exactly one ARPlacementController.");
        var placement = placements[0];
        var planes = placement.GetComponent<ARPlaneManager>();
        var origin = placement.GetComponent<Unity.XR.CoreUtils.XROrigin>();
        if (planes == null || origin == null || origin.Camera == null)
            throw new InvalidOperationException("The existing XR Origin needs its AR camera and plane manager.");
        if (InScene<SIHExtinguisherSelection>(scene).Length > 1 || InScene<SIHTrainingPrompts>(scene).Length > 1)
            throw new InvalidOperationException("Multiple equipment controllers or prompt canvases found; inspect them before setup.");

        backupFolder = "Backups/EquipmentSetup_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        Directory.CreateDirectory(backupFolder);
        Backup(scene.path);
        // Capture unsaved live changes as well as the existing disk file, before any edits.
        if (!EditorSceneManager.SaveScene(scene, backupFolder + "/ARTraining-live.unity", true))
            throw new IOException("Could not back up the current live scene; setup stopped.");
        if (TMP_Settings.defaultFontAsset == null)
        {
            // Import only missing essentials, never overwrite pre-existing TMP customization.
            if (AssetDatabase.IsValidFolder("Assets/TextMesh Pro"))
                throw new InvalidOperationException("TMP resources exist but default font is missing. Assign it in TMP Settings first.");
            TMP_PackageResourceImporter.ImportResources(true, false, false);
            throw new InvalidOperationException("TMP essentials import started. Run setup again after import finishes.");
        }

        Directory.CreateDirectory(Folder);
        AssetDatabase.Refresh();
        var prefab = GetOrCreatePrefab();
        var equipment = InScene<SIHExtinguisherSelection>(scene).SingleOrDefault();
        if (equipment == null)
        {
            var go = new GameObject("SIH Equipment Interaction");
            SceneManager.MoveGameObjectToScene(go, scene);
            equipment = go.AddComponent<SIHExtinguisherSelection>();
        }
        equipment.Configure(placement, origin.Camera, prefab);
        EditorUtility.SetDirty(equipment);

        var prompts = InScene<SIHTrainingPrompts>(scene).SingleOrDefault();
        if (prompts == null)
        {
            var canvasObject = new GameObject("SIH Training Prompts", typeof(RectTransform),
                typeof(Canvas), typeof(UnityEngine.UI.CanvasScaler));
            SceneManager.MoveGameObjectToScene(canvasObject, scene);
            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 20;
            var scaler = canvasObject.GetComponent<UnityEngine.UI.CanvasScaler>();
            scaler.uiScaleMode = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.matchWidthOrHeight = 0.5f;
            var safe = Rect("Safe Area", canvasObject.transform);
            safe.anchorMin = Vector2.zero; safe.anchorMax = Vector2.one;
            safe.offsetMin = safe.offsetMax = Vector2.zero;
            var panel = Rect("Prompt Panel", safe);
            panel.anchorMin = new Vector2(0.04f, 0.84f);
            panel.anchorMax = new Vector2(0.96f, 0.97f);
            panel.offsetMin = panel.offsetMax = Vector2.zero;
            var image = panel.gameObject.AddComponent<UnityEngine.UI.Image>();
            image.color = new Color(0.035f, 0.045f, 0.06f, 0.88f);
            image.raycastTarget = false;
            var textRect = Rect("Prompt", panel);
            textRect.anchorMin = Vector2.zero; textRect.anchorMax = Vector2.one;
            textRect.offsetMin = new Vector2(24, 14); textRect.offsetMax = new Vector2(-24, -14);
            var label = textRect.gameObject.AddComponent<TextMeshProUGUI>();
            label.font = TMP_Settings.defaultFontAsset;
            label.fontSize = 38;
            label.color = Color.white;
            label.alignment = TextAlignmentOptions.Center;
            label.text = "Move your phone slowly to scan a surface";
            label.raycastTarget = false;
            // Display-only canvas: no EventSystem or input module is necessary.
            prompts = canvasObject.AddComponent<SIHTrainingPrompts>();
            prompts.Configure(placement, planes, equipment, label, safe);
        }
        EditorUtility.SetDirty(prompts);
        EditorSceneManager.MarkSceneDirty(scene);
        AssetDatabase.SaveAssets();
        if (!EditorSceneManager.SaveScene(scene)) throw new IOException("Scene save failed.");
        Debug.Log("SIH equipment ready. Scene backup: " + Path.GetFullPath(backupFolder));
    }

    private static T[] InScene<T>(Scene scene) where T : Component =>
        scene.GetRootGameObjects().SelectMany(root => root.GetComponentsInChildren<T>(true)).ToArray();

    private static void Backup(string path)
    {
        if (!File.Exists(path)) return;
        string destination = Path.Combine(backupFolder, path);
        Directory.CreateDirectory(Path.GetDirectoryName(destination));
        File.Copy(path, destination, false);
        if (File.Exists(path + ".meta")) File.Copy(path + ".meta", destination + ".meta", false);
    }

    private static SIHExtinguisher GetOrCreatePrefab()
    {
        // Reuse the existing equipment asset even if it was renamed/moved.
        var candidates = AssetDatabase.FindAssets("t:Prefab", new[] { "Assets" })
            .Select(AssetDatabase.GUIDToAssetPath)
            .Where(path => Path.GetFileNameWithoutExtension(path).IndexOf("extinguisher", StringComparison.OrdinalIgnoreCase) >= 0 ||
                AssetDatabase.LoadAssetAtPath<GameObject>(path).GetComponent<SIHExtinguisher>() != null).ToArray();
        if (candidates.Length > 1) throw new InvalidOperationException("Multiple extinguisher prefabs found; inspect before setup.");
        string path = candidates.Length == 1 ? candidates[0] : PrefabPath;
        var existing = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        if (existing != null && existing.GetComponent<SIHExtinguisher>() != null)
        {
            var pin = existing.GetComponent<SIHSafetyPin>();
            if (pin == null || !pin.IsConfigured)
            {
                Backup(path);
                var root = PrefabUtility.LoadPrefabContents(path);
                try
                {
                    var shaft = root.transform.Find("Safety Pin");
                    var ring = root.transform.Find("Pull Ring");
                    if (shaft == null || ring == null)
                        throw new InvalidOperationException("Rebuild Detailed Extinguisher first: separate pin and ring are required.");
                    var interaction = root.GetComponent<SIHSafetyPin>();
                    if (interaction == null) interaction = root.AddComponent<SIHSafetyPin>();
                    interaction.Configure(shaft, ring);
                    PrefabUtility.SaveAsPrefabAsset(root, path);
                }
                finally { PrefabUtility.UnloadPrefabContents(root); }
            }
            return AssetDatabase.LoadAssetAtPath<GameObject>(path).GetComponent<SIHExtinguisher>();
        }
        return SIHRealisticExtinguisherModel.Build(path);
    }

    private static RectTransform Rect(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return (RectTransform)go.transform;
    }
}

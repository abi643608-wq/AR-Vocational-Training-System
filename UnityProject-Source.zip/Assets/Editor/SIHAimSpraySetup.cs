using System;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public static class SIHAimSpraySetup
{
    private static string backup;
    private const string FirePath="Assets/Prefabs/Fire/FireHazard.prefab";
    [MenuItem("Tools/SIH/Setup Aim and Spray")]
    public static void Setup()
    {
        var scene=SceneManager.GetActiveScene();
        if(EditorApplication.isPlayingOrWillChangePlaymode||scene.path!="Assets/Scenes/ARTraining.unity")throw new InvalidOperationException("Open the current ARTraining scene in Edit mode.");
        var placement=UnityEngine.Object.FindObjectsByType<ARPlacementController>(FindObjectsSortMode.None).Single();
        var equipment=UnityEngine.Object.FindObjectsByType<SIHExtinguisherSelection>(FindObjectsSortMode.None).Single();
        var prompts=UnityEngine.Object.FindObjectsByType<SIHTrainingPrompts>(FindObjectsSortMode.None).Single();
        var camera=placement.GetComponent<Unity.XR.CoreUtils.XROrigin>().Camera;
        backup="Backups/AimSpraySetup_"+DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        Directory.CreateDirectory(backup); Backup(scene.path);Backup(FirePath);
        if(!EditorSceneManager.SaveScene(scene,backup+"/ARTraining-live.unity",true))throw new IOException("Live scene backup failed");
        var fire=PrefabUtility.LoadPrefabContents(FirePath);
        try
        {
            // Apply tuning once: reruns never multiply scale, colors or emission.
            if(fire.GetComponent<SIHFireHazard>()==null)
            {
                fire.AddComponent<SIHFireHazard>();
                foreach(var ps in fire.GetComponentsInChildren<ParticleSystem>(true))
                {
                    var main=ps.main;main.scalingMode=ParticleSystemScalingMode.Hierarchy;
                    main.maxParticles=ps.name.Contains("Smoke")?64:ps.name.Contains("Spark")?40:80;
                    main.stopAction=ParticleSystemStopAction.None;
                    var lights=ps.lights;if(lights.enabled)lights.intensityMultiplier*=.65f;
                }
            }
            foreach(var ps in fire.GetComponentsInChildren<ParticleSystem>(true)) { var lights=ps.lights; if(lights.enabled){lights.intensityMultiplier=.008f;lights.maxLights=1;} }
            TuneFireMaterials(fire);
            PrefabUtility.SaveAsPrefabAsset(fire,FirePath);
        }
        finally{PrefabUtility.UnloadPrefabContents(fire);}
        var canvas=prompts.GetComponent<Canvas>();
        if(canvas.GetComponent<UnityEngine.UI.GraphicRaycaster>()==null)canvas.gameObject.AddComponent<UnityEngine.UI.GraphicRaycaster>();
        var events=UnityEngine.Object.FindObjectsByType<EventSystem>(FindObjectsSortMode.None);
        if(events.Length>1)throw new InvalidOperationException("Multiple EventSystems found");
        if(events.Length==0)new GameObject("SIH UI EventSystem",typeof(EventSystem),typeof(StandaloneInputModule));
        var controller=equipment.GetComponent<SIHAimSprayController>();
        if(controller==null)controller=equipment.gameObject.AddComponent<SIHAimSprayController>();
        var powder=equipment.GetComponent<SIHPowderSpray>();
        if(powder==null)powder=equipment.gameObject.AddComponent<SIHPowderSpray>();
        powder.Configure(PowderMaterial());
        var aim=Rect("Aim and Spray",canvas.transform,Vector2.zero,Vector2.one,Vector2.zero,Vector2.zero);
        var backing=Rect("Reticle Backing",aim,new Vector2(.5f,.5f),new Vector2(.5f,.5f),new Vector2(62,62),Vector2.zero);
        var backingImage=backing.GetComponent<UnityEngine.UI.Image>();if(backingImage==null)backingImage=backing.gameObject.AddComponent<UnityEngine.UI.Image>();backingImage.color=new Color(0,0,0,.6f);backingImage.raycastTarget=false;backing.SetAsFirstSibling();
        var reticle=Text("Centre Reticle",aim,new Vector2(.5f,.5f),new Vector2(.5f,.5f),new Vector2(80,80),Vector2.zero,"+",60);
        var status=Text("Aim Status",aim,new Vector2(.12f,.37f),new Vector2(.88f,.43f),Vector2.zero,Vector2.zero,"Aim at the base",28);
        // Button controls live under the existing safe area; the reticle stays at exact viewport centre.
        var safe=canvas.transform.Find("Safe Area");
        var button=Rect("Hold to Spray",aim,new Vector2(.18f,.09f),new Vector2(.82f,.19f),Vector2.zero,Vector2.zero);
        var image=button.GetComponent<UnityEngine.UI.Image>();if(image==null)image=button.gameObject.AddComponent<UnityEngine.UI.Image>();
        image.color=new Color(.12f,.28f,.4f);image.raycastTarget=true;
        Text("Label",button,Vector2.zero,Vector2.one,Vector2.zero,Vector2.zero,"HOLD TO SPRAY",36);
        var hold=button.GetComponent<SIHHoldToSpray>();if(hold==null)hold=button.gameObject.AddComponent<SIHHoldToSpray>();hold.Configure(controller);
        controller.Configure(placement,equipment,camera,powder,aim.gameObject,reticle,status,image);
        var sweep=controller.GetComponent<SIHSweepAssessment>();
        if(sweep==null)sweep=controller.gameObject.AddComponent<SIHSweepAssessment>();
        controller.ConfigureSweep(sweep);EditorUtility.SetDirty(sweep);
        SIHSweepFeedbackSetup.Wire(controller);
        prompts.ConfigureAim(controller);
        var reset=Rect("Reset Training",safe!=null?safe:canvas.transform,new Vector2(.72f,.02f),new Vector2(.97f,.075f),Vector2.zero,Vector2.zero);
        var resetImage=reset.GetComponent<UnityEngine.UI.Image>();if(resetImage==null)resetImage=reset.gameObject.AddComponent<UnityEngine.UI.Image>();resetImage.color=new Color(.18f,.2f,.24f,.95f);
        Text("Label",reset,Vector2.zero,Vector2.one,Vector2.zero,Vector2.zero,"RESET",28);
        var resetButton=reset.GetComponent<UnityEngine.UI.Button>();if(resetButton==null)resetButton=reset.gameObject.AddComponent<UnityEngine.UI.Button>();resetButton.targetGraphic=resetImage;
        if(!Enumerable.Range(0,resetButton.onClick.GetPersistentEventCount()).Any(i=>resetButton.onClick.GetPersistentTarget(i)==controller&&resetButton.onClick.GetPersistentMethodName(i)=="ResetPlacement"))
            UnityEventTools.AddPersistentListener(resetButton.onClick,controller.ResetPlacement);
        aim.gameObject.SetActive(false);
        EditorUtility.SetDirty(controller);EditorUtility.SetDirty(powder);EditorUtility.SetDirty(prompts);EditorUtility.SetDirty(hold);
        EditorSceneManager.MarkSceneDirty(scene);AssetDatabase.SaveAssets();EditorSceneManager.SaveScene(scene);
        Debug.Log("Aim and spray configured. Backup: "+backup);
    }
    private static void TuneFireMaterials(GameObject fire)
    {
        foreach(var renderer in fire.GetComponentsInChildren<ParticleSystemRenderer>(true))
        {
            var source=renderer.sharedMaterial;
            if(source==null||!source.HasProperty("_EmissionIntensity")||source.GetFloat("_EmissionIntensity")<=0)continue;
            string path="Assets/Materials/SIH_Equipment/SIH_Fire_"+renderer.name.Replace(" ","_")+".mat";
            Backup(path);
            var material=AssetDatabase.LoadAssetAtPath<Material>(path);
            if(material==null){material=new Material(source);AssetDatabase.CreateAsset(material,path);}
            float intensity=renderer.name.Contains("Spark")?20:renderer.name.Contains("Ash")?6:4;
            material.SetFloat("_EmissionIntensity",intensity);
            var tint=material.GetColor("_Color"); tint.r=.95f;tint.g=.7f;tint.b=.45f;material.SetColor("_Color",tint);
            renderer.sharedMaterial=material;EditorUtility.SetDirty(material);
        }
    }
    private static Material PowderMaterial()
    {
        const string path="Assets/Materials/SIH_Equipment/SIH_Powder.mat";
        var existing=AssetDatabase.LoadAssetAtPath<Material>(path);if(existing!=null)return existing;
        const string texturePath="Assets/Materials/SIH_Equipment/SIH_Powder.png";
        Backup(texturePath);var texture=new Texture2D(64,64,TextureFormat.RGBA32,false);
        for(int y=0;y<64;y++)for(int x=0;x<64;x++) {float r=Vector2.Distance(new Vector2(x,y),new Vector2(31.5f,31.5f))/31.5f;texture.SetPixel(x,y,new Color(1,1,1,Mathf.Pow(Mathf.Clamp01(1-r),2)));}
        texture.Apply();File.WriteAllBytes(texturePath,texture.EncodeToPNG());UnityEngine.Object.DestroyImmediate(texture);AssetDatabase.ImportAsset(texturePath);
        var importer=(TextureImporter)AssetImporter.GetAtPath(texturePath);importer.alphaIsTransparency=true;importer.mipmapEnabled=false;importer.maxTextureSize=64;importer.SaveAndReimport();
        var material=new Material(Shader.Find("Universal Render Pipeline/Particles/Unlit"));
        material.SetFloat("_Surface",1);material.SetFloat("_Blend",0);material.SetFloat("_SrcBlend",(float)UnityEngine.Rendering.BlendMode.SrcAlpha);
        material.SetFloat("_DstBlend",(float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);material.SetFloat("_ZWrite",0);
        material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");material.renderQueue=3000;
        material.SetTexture("_BaseMap",AssetDatabase.LoadAssetAtPath<Texture2D>(texturePath));
        AssetDatabase.CreateAsset(material,path);return material;
    }
    private static void Backup(string path)
    {
        if(!File.Exists(path))return;string target=Path.Combine(backup,path);Directory.CreateDirectory(Path.GetDirectoryName(target));
        if(!File.Exists(target))File.Copy(path,target);
        if(File.Exists(path+".meta")&&!File.Exists(target+".meta"))File.Copy(path+".meta",target+".meta");
    }
    private static RectTransform Rect(string name,Transform parent,Vector2 min,Vector2 max,Vector2 size,Vector2 pos)
    {
        var child=parent.Find(name);var rect=child!=null?(RectTransform)child:new GameObject(name,typeof(RectTransform)).GetComponent<RectTransform>();
        rect.SetParent(parent,false);rect.anchorMin=min;rect.anchorMax=max;rect.pivot=new Vector2(.5f,.5f);rect.sizeDelta=size;rect.anchoredPosition=pos;return rect;
    }
    private static TMP_Text Text(string name,Transform parent,Vector2 min,Vector2 max,Vector2 size,Vector2 pos,string value,float fontSize)
    {
        var rect=Rect(name,parent,min,max,size,pos);var label=rect.GetComponent<TextMeshProUGUI>();if(label==null)label=rect.gameObject.AddComponent<TextMeshProUGUI>();
        label.font=TMP_Settings.defaultFontAsset;label.text=value;label.fontSize=fontSize;label.color=Color.white;label.alignment=TextAlignmentOptions.Center;label.raycastTarget=false;return label;
    }
}





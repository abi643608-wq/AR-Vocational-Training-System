> Historical prototype-1 notes. Current question flow and prototype-2 rubric: [SCENARIO_QUESTIONS.md](SCENARIO_QUESTIONS.md). The phone no-sweep failure case and offline reload remain UNVERIFIED.

# Assessment and results — prototype v1

Implemented and wired in the current `Assets/Scenes/ARTraining.unity`. Existing source files and the scene were backed up under `Backups/Assessment_20260927_213819`; setup invocations also create `Backups/AssessmentSetup_*` scene backups. The existing aim/route controller still owns training state. The new recorder observes it; it is not another training manager.

## Unity setup and tuning

1. Open `D:\AR` in Unity 6000.3.24f1 and open `Assets/Scenes/ARTraining.unity`. Wait for compilation. The scene is already wired.
2. To reapply wiring, leave Play mode and use **Tools > SIH > Setup Assessment Results**. This backs up the live and saved scene and reuses existing objects, Canvas, EventSystem and references. It does not rebuild the extinguisher/fire or replace AR settings.
3. Select **SIH Equipment Interaction > SIH Assessment Recorder > Rules**. Defaults are rules version `prototype-1`, pass threshold **70%**, valid-aim spraying threshold **3 seconds**, and sustained off-target mistake threshold **1 second**. The six point weights and required-evidence flags are configurable. Change the version when changing the project rubric. Each attempt stores its own copy of these settings; old records are not rescored from new Inspector values.
4. Open **File > Build Profiles**, select the existing **Android** profile, confirm `Assets/Scenes/ARTraining.unity` is enabled in the scene list, select the connected device, and choose **Build And Run**. Keep existing XR, graphics, camera and renderer settings. Use a new APK output filename for this build.

## What is measured

Timing begins at **CONFIRM & START**, after route setup, and again on **RESTART EXERCISE** with a new attempt ID. Active duration excludes suspension, lost app focus and unreliable AR tracking. The first recovery frame and unusually long sampling gaps are excluded. Duration has no effect on points.

| Item | Default weight | Evidence |
|---|---:|---|
| Pin removed in sequence | 20 | Actual selection event for the same extinguisher, followed by its confirmed pin-removal event before spraying |
| Valid aim while spraying | 20 | Accumulated valid-base-hit time from active spray updates; at least 3 seconds by default |
| Required sweep passes | 20 | Existing sweep assessment reaches its configured required pass count; stationary aim does not count |
| Fire extinguished | 20 | Fire-extinguished event and actual hazard health state |
| Exit identified | 10 | Existing successful training-exit selection event |
| Ordered route and assembly | 10 | All observed stop events in order, followed by ordered-route/assembly completion |

Hazard identification and choosing an extinguisher type are explicitly **Not assessed** because these interactions do not exist. They contribute no points. Disabled or missing evidence sources make the affected item **Not assessed** and exclude its weight from available points; such a required-evidence gap prevents a pass. A missed criterion with a functioning observation source is assessed at zero points, not silently excluded.

Each award is latched once per attempt. Exercise completion and performance are separate:

- **Incomplete:** the exercise did not reach assembly completion.
- **Assessment incomplete:** the exercise finished, but required evidence is unavailable or there are no available points.
- **Needs practice:** the exercise finished with required evidence assessed, but the score is below the configured threshold.
- **Pass:** the exercise finished, required evidence is assessed and the threshold is met.

The 70% threshold is a **project prototype setting, not an official safety standard**. Under the requested rubric, finishing everything except sweep technique earns **80/100 and passes** at 70%; sweep remains visibly **0/20**. Required-evidence flags require reliable assessment, not success on every criterion. No certificates are generated.

The only defined mistake in this version is continuously holding spray outside the valid fire-base target for at least 1 second with reliable tracking. It counts once per uninterrupted off-target episode; release, valid aim, tracking loss or suspension ends that episode. These entries have timestamps and active-duration offsets. Tracking failures, UI misses and automatic prompts are not mistakes. Mistakes do not deduct points. Hints display **Not available**; no help-request interaction exists and automatic guidance is not counted.

## Results and local history

Assembly completion opens one opaque, scrollable results screen. It hides the old prompt/route HUD while displayed, follows the mobile safe area and blocks UI touches across the whole view. Scroll for all item explanations, active duration, mistake entries, hint availability and attempt details. The footer retains **RESTART EXERCISE** and **RECONFIGURE ROUTE**.

Restart creates a fresh ID and zeroed measurements while preserving the confirmed route within its valid AR session. Reconfigure interrupts an unfinished attempt and clears the live route, while retaining saved assessment history. **LAST RESULTS** in route setup displays the most recent completed/interrupted record. Recovered interrupted results appear on the next launch. A full history browser is not part of this version; all historical records remain on disk.

Storage is offline in:

`Application.persistentDataPath/SIHAssessments/v1/`

Each finalized attempt has `<attemptId>.json`; `pending.json` is the active checkpoint, with a previous-file backup. Each record includes schema version, rules version and rule snapshot, unique ID, UTC start/end timestamps, active duration, measured action values, per-item evidence/results, mistakes/hints, points and completion/outcome. There are **no raw AR route coordinates**.

Writes flush a same-directory temporary file and commit by atomic rename/replace. Final files are immutable and duplicate completion does not create another record. Checkpoints are saved every 2 seconds and on significant actions/suspension; an abrupt process kill may lose the last checkpoint interval. Next launch finalizes a leftover in-progress checkpoint as interrupted rather than resuming its AR coordinates. Missing storage starts empty; malformed/unsupported records are skipped without deleting valid history. A valid checkpoint backup can recover a damaged primary checkpoint. Storage errors are caught and displayed as a local-save warning on results; device storage and Android filesystem behavior still require phone testing. There is no cloud sync, upload or certificate.

## Android acceptance tests

1. **Full success:** configure and confirm the route, select extinguisher, remove pin, aim accurately for at least 3 seconds, complete both sweep passes, extinguish, identify exit and reach every stop/assembly. Expect **Exercise Complete / Pass / 100/100**, sweep 2/2, and your actual route-stop count (for your four-stop route, 4/4). Check active duration, UTC timestamps and unique attempt ID. Hazard/type rows must say Not assessed and hints Not available.
2. **No sweep:** restart; hold an accurate stationary spray until extinction, then finish evacuation. Expect **Exercise Complete / 80/100 / Pass** at the default threshold, sweep 0/20 with explicit feedback. Extinction must not wait for sweep completion. For a Needs practice test, temporarily use a 90% prototype threshold in the Inspector, rebuild, repeat and expect Needs practice; restore 70 afterward. Each record must retain the threshold it used.
3. **Unfinished route:** start, extinguish and reach only part of the route. Tap Reconfigure Route or Restart Exercise. Use LAST RESULTS during setup (after reconfiguration) or inspect JSON: the abandoned attempt must be Interrupted/Incomplete, with the partial stop count. Restart must have a different ID, no inherited points, zero aim time and no previous mistake entries.
4. **Aim evidence:** spray off target, then release; no valid-aim time or aim points should accrue from a single hit. With reliable tracking, one continuous off-target spray longer than 1 second should record one mistake, not one per frame. Resume a separate such episode to record another. Finish accurately; mistakes must not reduce points.
5. **Pause/focus:** during an active attempt, note its progress, background the app for 10 seconds and resume. Also cover the camera until tracking becomes unreliable. Spray must stop; those intervals must not inflate active duration or add mistakes. ARCore may create a new session on resume; in that case expect an interrupted record and route reconfiguration, not reuse of old coordinates.
6. **Results usability:** scroll from top to bottom in portrait and landscape. Check labels/buttons remain readable within the safe area, no completion panels overlap, and tapping/dragging anywhere on results cannot move the fire or interact with world objects. Test both footer actions. Reconfigure must retain history; restart must reset the exercise while retaining a valid route.
7. **Offline/interruption:** turn off networking. Complete an attempt, reopen the app and use LAST RESULTS to verify it survives. Start another, wait more than 2 seconds, force-stop the app before assembly, then relaunch: expect an interrupted result from the checkpoint and fresh route setup. Confirm the previous completed JSON remains unchanged. Repeated taps/standing at assembly must not create duplicate final files.
8. **Missing-evidence development test:** in a temporary development build, disable only `SIH Sweep Assessment` before starting an attempt. Complete the exercise without changing the other components. Expect Sweep Not assessed, **80/80 / Assessment incomplete**, not Pass. Re-enable the component and rebuild for normal training. Do not disable the entire equipment object.
9. **Corrupt-file development test:** on a disposable local test copy, keep one valid completed record, add malformed JSON and relaunch. Valid history must still load without crashing. Corrupt an active checkpoint only after making a copy; its prior valid `.bak` may be recovered. Never replace the user's real records to run this test.

Use Android Studio Device Explorer (or `adb run-as` for a debuggable build) to inspect the application's own persistent-data folder. The exact package directory follows the existing Application Identifier; no package setting was changed.

## Validation performed and limitations

- Unity compilation succeeded.
- Scoring/storage tests passed: fully successful attempt; no-sweep score; unfinished route; missing required evidence; Needs practice; single-hit aim rejection; immutable/idempotent final save; checkpoint replacement; interrupted recovery; corrupt-file handling and backup recovery.
- Synthetic Play mode tests drove actual selection/pin events, controller spray updates with geometric base hits, sweep/fire events, and ordered route arrival callbacks. Passed full 100/100, no-sweep 80/100, and disabled-sweep 80/80 Assessment incomplete. They also checked app-pause/tracking duration exclusion, mistake behavior, duplicate completion, fresh restart IDs and retained interrupted history. Storage was redirected to isolated `.utmp` test directories, not real phone history.
- Results scrolling and full-screen UI raycast blocking were verified. Actual Editor Game view previews were inspected in landscape and 1080x1920 portrait, including the lower result details. These are Editor previews, not physical-phone visual verification.
- Re-running setup preserved object count, a single recorder and EventSystem, and one callback per results action.
- Existing prefabs, settings assets, packages and ProjectSettings matched the pre-task backup. Camera serialization was unchanged; Depth Texture, Mobile AR Background Renderer Feature and `TrackableType.Planes` were preserved.
- No Android APK build or physical-device test was performed. Android file replacement under process/power interruption, real AR tracking/focus recovery, mobile safe-area behavior and touch scrolling still need the checklist above.

Reproducible Unity CLI eval test sources are in `Tests/Assessment` (outside Assets, so they are not shipped). Model and wiring tests run in Edit mode. Integration variants require Play mode, the wired ARTraining scene, and a normal Editor frame interval. They use synthetic plane/input/time samples and temporary storage; they are not device tests.

